package uk.co.umbaska.Attributes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Zachary on 11/7/2015.
 */
public class AttributeManager {

    public static HashMap<String, Attributes_V1_8_R3> storageR3 = new HashMap<>();
    public static HashMap<Attributes_V1_8_R3, List<Attributes_V1_8_R3.Attribute>> attributeStorageR3 = new HashMap<>();
    public static HashMap<String, Attributes_V1_8_R1> storageR1 = new HashMap<>();
    public static HashMap<Attributes_V1_8_R1, List<Attributes_V1_8_R1.Attribute>> attributeStorageR1 = new HashMap<>();

    public static void update(Attributes_V1_8_R3 at){
        List<Attributes_V1_8_R3.Attribute> list = new ArrayList<>();
        if (attributeStorageR3.get(at) == null){
            attributeStorageR3.put(at, list);
        }
        attributeStorageR3.get(at).clear();
        for (Attributes_V1_8_R3.Attribute attribute : at.values()){
            attributeStorageR3.get(at).add(attribute);
        }
    }

    public static void update(Attributes_V1_8_R1 at){
        List<Attributes_V1_8_R1.Attribute> list = new ArrayList<>();
        if (attributeStorageR1.get(at) == null){
            attributeStorageR1.put(at, list);
        }
        attributeStorageR1.get(at).clear();
        for (Attributes_V1_8_R1.Attribute attribute : at.values()){
            attributeStorageR1.get(at).add(attribute);
        }
    }

}
