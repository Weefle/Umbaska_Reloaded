package uk.co.umbaska.Attributes;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import net.minecraft.server.v1_8_R1.NBTTagCompound;
import org.bukkit.craftbukkit.v1_8_R1.inventory.CraftItemStack;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import uk.co.umbaska.Enums.Attributes_V1_8_R1;

/**
 * Created by Zachary on 6/30/2015.
 */
public class ExprGenericItemAttribute_V1_8_R1 extends SimpleExpression<ItemStack> {

    private Expression<ItemStack> item;
    private Expression<String> attribute;
    private Expression<Number> value;

    @Override
    public boolean isSingle() {
        return true;
    }
    public Class<? extends ItemStack> getReturnType(){
        return ItemStack.class;
    }

    @Override
    protected ItemStack[] get(Event event) {
        ItemStack item = this.item.getSingle(event);
        Number b = this.value.getSingle(event);
        String ab = attribute.getSingle(event);
        net.minecraft.server.v1_8_R1.ItemStack nmsstack = CraftItemStack.asNMSCopy(item);
        NBTTagCompound compound = null;
        if (nmsstack.getTag() != null){
            compound = CraftItemStack.asNMSCopy(item).getTag();
        }else{
            compound = new NBTTagCompound();
        }
        compound.setDouble(ab, b.doubleValue());
        nmsstack.setTag(compound);
        return new ItemStack[]{CraftItemStack.asBukkitCopy(nmsstack)};
    }

    public String getNBTName(Attributes_V1_8_R1 i){
        if (i == Attributes_V1_8_R1.ATTACK_DAMAGE){
            return "generic.attackDamage";
        }else if (i == Attributes_V1_8_R1.FOLLOW_RANGE){
            return "generic.followRange";
        }else if (i == Attributes_V1_8_R1.KNOCKBACK_RESISTANCE){
            return "generic.knockbackResistance";
        }else if (i == Attributes_V1_8_R1.MAX_HEALTH){
            return "generic.maxHealth";
        }else if (i == Attributes_V1_8_R1.MOVEMENT_SPEED){
            return "generic.movementSpeed";
        }
        return "";
    }


    @Override
    public String toString(Event event, boolean b){
        return "Set Item Attribute";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        attribute = (Expression<String>) expressions[1];
        item = (Expression<ItemStack>) expressions[0];
        value = (Expression<Number>) expressions[2];
        return true;
    }

}
