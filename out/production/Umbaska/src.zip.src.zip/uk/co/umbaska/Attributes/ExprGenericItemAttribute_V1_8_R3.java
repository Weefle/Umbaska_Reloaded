package uk.co.umbaska.Attributes;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;

/**
 * Created by Zachary on 6/30/2015.
 */
public class ExprGenericItemAttribute_V1_8_R3 extends SimpleExpression<ItemStack> {

    private Expression<ItemStack> item;
    private Expression<String> attribute;
    private Expression<Number> value;

    @Override
    public boolean isSingle() {
        return true;
    }
    public Class<? extends ItemStack> getReturnType(){
        return ItemStack.class;
    }

    @Override
    protected ItemStack[] get(Event event) {
        ItemStack item = this.item.getSingle(event);
        Number b = this.value.getSingle(event);
        String ab = attribute.getSingle(event);
        net.minecraft.server.v1_8_R3.ItemStack nmsstack = CraftItemStack.asNMSCopy(item);
        NBTTagCompound compound = null;
        if (nmsstack.getTag() != null){
            compound = CraftItemStack.asNMSCopy(item).getTag();
        }else{
            compound = new NBTTagCompound();
        }
        compound.setDouble(ab, b.doubleValue());
        nmsstack.setTag(compound);
        Bukkit.broadcastMessage(compound.toString() + "\n" + nmsstack.getTag().toString());
        return new ItemStack[]{CraftItemStack.asBukkitCopy(nmsstack)};
    }


    @Override
    public String toString(Event event, boolean b){
        return "Set Item Attribute";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        attribute = (Expression<String>) expressions[1];
        item = (Expression<ItemStack>) expressions[0];
        value = (Expression<Number>) expressions[2];
        return true;
    }

}
