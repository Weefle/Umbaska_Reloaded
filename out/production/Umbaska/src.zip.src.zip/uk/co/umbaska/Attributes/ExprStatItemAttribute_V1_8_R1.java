package uk.co.umbaska.Attributes;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import net.minecraft.server.v1_8_R1.NBTTagCompound;
import org.bukkit.craftbukkit.v1_8_R1.inventory.CraftItemStack;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import uk.co.umbaska.Enums.Attributes_V1_8_R1;
import uk.co.umbaska.Enums.Operation;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by Zachary on 6/30/2015.
 */
public class ExprStatItemAttribute_V1_8_R1 extends SimpleExpression<ItemStack> {

    private Expression<ItemStack> item;
    private Expression<Attributes_V1_8_R1> attribute;
    private Expression<Number> value;
    private Expression<Operation> operation;

    @Override
    public boolean isSingle() {
        return true;
    }
    public Class<? extends ItemStack> getReturnType(){
        return ItemStack.class;
    }

    @Override
    protected ItemStack[] get(Event event) {
        ItemStack item = this.item.getSingle(event);
        Number b = this.value.getSingle(event);
        Attributes_V1_8_R1 ab = attribute.getSingle(event);
        Operation operation = this.operation.getSingle(event);
        String itemUUID = null;
        net.minecraft.server.v1_8_R1.ItemStack nmsstack = CraftItemStack.asNMSCopy(item);
        NBTTagCompound compound = null;
        if (nmsstack.getTag() != null){
            compound = CraftItemStack.asNMSCopy(item).getTag();
        }else{
            compound = new NBTTagCompound();
        }
        if (compound.getString("umbUUID") == "" || compound.getString("umbUUID") == null){
            itemUUID = UUID.randomUUID().toString();
            compound.setString("umbUUID", itemUUID);
        }else{
            itemUUID = compound.getString("umbUUID");
        }
        nmsstack.setTag(compound);
        item = CraftItemStack.asBukkitCopy(nmsstack);

        uk.co.umbaska.Attributes.Attributes_V1_8_R1 attributes = new uk.co.umbaska.Attributes.Attributes_V1_8_R1(item);
        List<uk.co.umbaska.Attributes.Attributes_V1_8_R1.Attribute> list = new ArrayList<>();
        if (AttributeManager.attributeStorageR1.get(attributes) == null){
            AttributeManager.attributeStorageR1.put(attributes, list);
        }
        if (AttributeManager.storageR1.containsKey(itemUUID)){
            attributes = AttributeManager.storageR1.get(itemUUID);
            if (AttributeManager.attributeStorageR1.get(attributes).size() > 0) {
                for (uk.co.umbaska.Attributes.Attributes_V1_8_R1.Attribute atrib : AttributeManager.attributeStorageR1.get(attributes)) {
                    if (atrib.getName() == getNBTName(ab)) {
                        attributes.remove(atrib);
                    }
                }
            }
        }
        attributes.add(uk.co.umbaska.Attributes.Attributes_V1_8_R1.Attribute.newBuilder().name(getNBTName(ab)).amount(b.doubleValue()).type(uk.co.umbaska.Attributes.Attributes_V1_8_R1.AttributeType.fromId(getNBTName(ab))).operation(operation).build());
        if (!AttributeManager.storageR1.containsKey(item)){
            AttributeManager.storageR1.put(itemUUID, attributes);
        }
        AttributeManager.update(attributes);
        return new ItemStack[]{attributes.getStack()};
    }

    public String getNBTName(Attributes_V1_8_R1 i){
        if (i == Attributes_V1_8_R1.ATTACK_DAMAGE){
            return "generic.attackDamage";
        }else if (i == Attributes_V1_8_R1.FOLLOW_RANGE){
            return "generic.followRange";
        }else if (i == Attributes_V1_8_R1.KNOCKBACK_RESISTANCE){
            return "generic.knockbackResistance";
        }else if (i == Attributes_V1_8_R1.MAX_HEALTH){
            return "generic.maxHealth";
        }else if (i == Attributes_V1_8_R1.MOVEMENT_SPEED){
            return "generic.movementSpeed";
        }
        return "";
    }


    @Override
    public String toString(Event event, boolean b){
        return "Set Item Attribute";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        attribute = (Expression<Attributes_V1_8_R1>) expressions[1];
        item = (Expression<ItemStack>) expressions[0];
        value = (Expression<Number>) expressions[2];
        operation = (Expression<Operation>) expressions[3];
        return true;
    }

}
