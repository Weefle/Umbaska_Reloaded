package uk.co.umbaska.Bungee;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;
import uk.co.umbaska.Main;

public class EffBungeeBroadcast extends Effect {
    private Expression<String> msg;

    protected void execute(Event event)
    {
        String message = this.msg.getSingle(event);
        for (String server : Main.messenger.cache.allServers) {
            for (String ps : Main.messenger.cache.playersOnlineServer.get(server)) {
                Main.messenger.sendMsgToPlayer(ps, message);
            }
        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "Change server";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        msg = (Expression<String>) expressions[0];
        return true;
    }
}
