/*
 * Messneger.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/


package uk.co.umbaska.Bungee;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Messenger
        implements PluginMessageListener
{
    public Plugin plugin;
    public ByteArrayDataInput bytein;
    public Cache cache;

    public Messenger(Plugin j)
    {
        j.getServer().getMessenger().registerOutgoingPluginChannel(j, "BungeeCord");
        j.getServer().getMessenger().registerIncomingPluginChannel(j, "BungeeCord", this);
        //	Bukkit.getPluginManager().getPlugin("BukkitBungee").getPluginLoader().disablePlugin(Bukkit.getPluginManager().getPlugin("BukkitBungee"));
        plugin = j;
        cache = new Cache();
    }

    public Messenger(Plugin j, Boolean autoCache, Integer autoCacheHeartBeat)
    {
        j.getServer().getMessenger().registerOutgoingPluginChannel(j, "BungeeCord");
        j.getServer().getMessenger().registerIncomingPluginChannel(j, "BungeeCord", this);
        //	Bukkit.getPluginManager().getPlugin("BukkitBungee").getPluginLoader().disablePlugin(Bukkit.getPluginManager().getPlugin("BukkitBungee"));
        plugin = j;
        cache = new Cache(autoCache, autoCacheHeartBeat, j);
    }

    public void onPluginMessageReceived(String channel, Player player, byte[] message)
    {
        if (!channel.equals("BungeeCord")) {
            return;
        }
        bytein = ByteStreams.newDataInput(message);
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));
        try
        {
            String subChannel = in.readUTF();
            if (subChannel.equals("KickPlayer"))
            {
                short size = in.readShort();
                byte[] bytes = new byte[size];
                in.readFully(bytes);
                DataInputStream cmdMsg = new DataInputStream(new ByteArrayInputStream(bytes));
                String reason = cmdMsg.readUTF();
                String executor = cmdMsg.readUTF();
                Player executingPlayer = Bukkit.getPlayer(executor);
                if (executingPlayer == null) {
                    return;
                }
                executingPlayer.kickPlayer(colorString(reason));
            }
            if (subChannel.equals("Message"))
            {
                short size = in.readShort();
                byte[] bytes = new byte[size];
                in.readFully(bytes);
                DataInputStream cmdMsg = new DataInputStream(new ByteArrayInputStream(bytes));
                String msg2Send = cmdMsg.readUTF();
                String executor = cmdMsg.readUTF();
                Player executingPlayer = Bukkit.getPlayer(executor);
                if (executingPlayer == null) {
                    return;
                }
                executingPlayer.sendMessage(colorString(msg2Send));
            }
            if (subChannel.equals("GetServers")) {
                String _temp = in.readUTF();
                _temp = _temp.replace(" and ", " ");
                _temp = _temp.replace(", ", " ");
                _temp = _temp.replace(" ", ", ");
                cache.allServers.clear();
                for (String s : _temp.split(", ")){
                    cache.allServers.add(s);
                }
            }
            if (subChannel.equals("PlayerList"))
            {
                String plServer = in.readUTF();
                if (plServer.equalsIgnoreCase("ALL")) {
                    String originalPlayerList = in.readUTF();
                    cache.allPlayersOnline.clear();
                    for (String s : originalPlayerList.split(", ")) {
                        cache.allPlayersOnline.add(s);
                    }
                }else{
                    String originalPlayerList = in.readUTF();
                    List<String> playersOnline = new ArrayList<>();
                    for (String s : originalPlayerList.split(", ")) {
                        playersOnline.add(s);
                    }
                    cache.playersOnlineServer.put(plServer, playersOnline);
                }
            }
            if (subChannel.equals("PlayerCount")) {
                String inUTF = in.readUTF();
                if (inUTF.equalsIgnoreCase("ALL")) {
                    cache.playersOnline = in.readShort();
                } else {
                    cache.online.put(inUTF, in.readInt());
                }
            }
            if (subChannel.equals("ConsoleCommand"))
            {
                short size = in.readShort();
                byte[] bytes = new byte[size];
                in.readFully(bytes);
                DataInputStream cmdMsg = new DataInputStream(new ByteArrayInputStream(bytes));
                String command = cmdMsg.readUTF();
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            }
            else if (subChannel.equals("PlayerCommand"))
            {
                short size = in.readShort();
                byte[] bytes = new byte[size];
                in.readFully(bytes);
                DataInputStream cmdMsg = new DataInputStream(new ByteArrayInputStream(bytes));
                String command = cmdMsg.readUTF();
                String executor = cmdMsg.readUTF();
                Player executingPlayer = Bukkit.getPlayer(executor);
                if (executingPlayer == null) {
                    return;
                }
                Bukkit.dispatchCommand(executingPlayer, command);
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public String colorString(String s)
    {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public Integer getServerCount(String server)
    {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("PlayerCount");
        out.writeUTF(server);
        try
        {
            sendAnonymous(out.toByteArray());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return cache.online.get(server);
    }

    public List<String> getAllPlayersOnServer(String server)
    {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("PlayerList");
        out.writeUTF(server);
        try
        {
            sendAnonymous(out.toByteArray());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return cache.playersOnlineServer.get(server);
    }

    public List<String> getAllPlayers()
    {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("PlayerList");
        out.writeUTF("ALL");
        try
        {
            sendAnonymous(out.toByteArray());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return cache.allPlayersOnline;
    }

    public List<String> getAllServers()
    {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("GetServers");
        try
        {
            sendAnonymous(out.toByteArray());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return cache.allServers;
    }

    public void sendMsgToPlayer(String player, String message) {
        ByteArrayOutputStream msg = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(msg);
        try
        {
            out.writeUTF("Message");
            out.writeUTF(player);
            out.writeUTF(message);
            out.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        sendAnonymous(msg.toByteArray());
    }

    public void kickPlayer(String player, String message)
    {
        ByteArrayOutputStream msg = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(msg);
        try
        {
            out.writeUTF("KickPlayer");
            out.writeUTF(player);
            out.writeUTF(message);
            out.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        sendAnonymous(msg.toByteArray());
    }

    public List<Player> getOnlinePlayers(){
        List<Player> players = new ArrayList<>();
        for (World w : Bukkit.getWorlds()){
            for (Player e : w.getPlayers()){
                players.add(e);
            }
        }
        return players;
    }

    public void sendAnonymous(byte[] message)
    {
        if (getOnlinePlayers().size() < 1) {
            return;
        }
        getOnlinePlayers().get(0).sendPluginMessage(plugin, "BungeeCord", message);
    }

    public void sendTo(byte[] message, Player[] players)
    {
        for (Player player : players) {
            player.sendPluginMessage(plugin, "BungeeCord", message);
        }
    }
}
