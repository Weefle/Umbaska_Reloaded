package uk.co.umbaska.Enums;

/**
 * Created by Zach on 17/07/15.
 */
public enum BarType{
	NORMAL, REGULAR, LOAD_UP, TIME_DOWN;
}