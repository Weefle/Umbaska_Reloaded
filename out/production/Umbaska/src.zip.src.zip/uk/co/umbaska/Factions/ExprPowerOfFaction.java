package uk.co.umbaska.Factions;


import ch.njol.skript.expressions.base.SimplePropertyExpression;
import com.massivecraft.factions.entity.Faction;

public class ExprPowerOfFaction extends
		SimplePropertyExpression<Faction, Double> {

	@Override
	public Class<? extends Double> getReturnType() {

		return Double.class;
	}

	@Override
	public Double convert(Faction faction) {
		return faction.getPower();
	}

	@Override
	protected String getPropertyName() {
		return "faction power";
	}
}
