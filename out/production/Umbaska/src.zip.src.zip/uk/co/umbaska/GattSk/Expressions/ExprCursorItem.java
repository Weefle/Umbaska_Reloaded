package uk.co.umbaska.GattSk.Expressions;

import ch.njol.skript.ScriptLoader;
import ch.njol.skript.Skript;
import ch.njol.skript.classes.Changer;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.skript.log.ErrorQuality;
import ch.njol.util.Kleenean;
import ch.njol.util.coll.CollectionUtils;
import org.bukkit.event.Event;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import uk.co.umbaska.GattSk.Extras.Collect;

public class ExprCursorItem extends SimpleExpression<ItemStack>{


	public Class<? extends ItemStack> getReturnType() {

		return ItemStack.class;
	}

	@Override
	public boolean isSingle() {
		return true;
	}

	@Override
	public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
		if (!ScriptLoader.isCurrentEvent(InventoryClickEvent.class)){
			Skript.error("Cannot use Cursor Item outside of Click Inventory event", ErrorQuality.SEMANTIC_ERROR);
			return false;
		}
		return true;
	}

	@Override
	public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
		return "cursor item";
	}

	@Override
	@javax.annotation.Nullable
	protected ItemStack[] get(Event event) {
		return Collect.asArray(((InventoryClickEvent) event).getWhoClicked().getOpenInventory().getCursor());
	}

	@Override
	public void change(Event e, Object[] delta, Changer.ChangeMode mode) {
		ItemStack newItem = (ItemStack)(delta[0]);
		if (mode == Changer.ChangeMode.SET) {
			((InventoryClickEvent) e).getWhoClicked().getOpenInventory().setCursor(newItem);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<?>[] acceptChange(final Changer.ChangeMode mode) {
		return CollectionUtils.array(ItemStack.class);
	}

}