package uk.co.umbaska.JSON;

/**
 * Created by Zach on 28/07/15.
 */
public class EffJsonBook {
}
