package uk.co.umbaska.Managers;

import ch.njol.skript.Skript;
import ch.njol.skript.conditions.base.PropertyCondition;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import uk.co.umbaska.Main;
import uk.co.umbaska.mcMMO.CondIsUsingAdminChat;
import uk.co.umbaska.mcMMO.CondIsUsingPartyChat;

@SuppressWarnings("unused")
public class Conditions {

    public static Boolean use_bungee = Main.getInstance().getConfig().getBoolean("use_bungee");
    public static Boolean debugInfo = Main.getInstance().getConfig().getBoolean("debug_info");

	private static String version = Register.getVersion();

    @SuppressWarnings("rawtypes")
	private static void registerNewCondition(String name, String cls, String syntax, Boolean multiversion){
        if (Skript.isAcceptRegistrations()){
            if (multiversion){
                Class newCls = Register.getClass(cls);
                if (newCls == null) {
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Condition for " + name + " due to Can't find Class!");
                    return;
                }
                registerNewCondition(name, newCls, syntax);
            }
            else{
                try {
                    registerNewCondition(name, Class.forName(cls), syntax);
                }catch (ClassNotFoundException e){
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Condition for " + name + " due to Wrong Spigot/Bukkit Version!");
                }
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Condition for " + name + " due to Skript Not Accepting Registrations");
        }
    }

    @SuppressWarnings("rawtypes")
	private static void registerNewCondition(String name, Class cls, String syntax){
        if (Skript.isAcceptRegistrations()){
            registerNewCondition(cls, syntax);
            if (debugInfo) {
                Bukkit.getLogger().info("Umbaska »»» Registered Condition for " + name + " with syntax \n" + syntax);
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Condition for " + name + " due to Skript Not Accepting Registrations");
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	private static void registerNewCondition(Class cls, String syntax){
        if (Skript.isAcceptRegistrations()){
           	Skript.registerCondition(cls, syntax);
            if (debugInfo) {
                Bukkit.getLogger().info("Umbaska »»» Registered Condition for " + cls.getName() + " with syntax\n " + syntax);
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Condition for " + cls.getName() + " due to Skript Not Accepting Registrations");
        }
    }

    @SuppressWarnings("deprecation")
    public static void runRegister(){
        //region MIST
		//registerNewCondition(CondDoesntContain.class, "%object% doesn[']t contain %object%");
        //endregion
        if (Bukkit.getServer().getPluginManager().getPlugin("SkRambled") == null) {
            //region MCMMO
            Plugin pl = Bukkit.getServer().getPluginManager().getPlugin("mcMMO");
            if (pl != null) {
                PropertyCondition.register(CondIsUsingPartyChat.class, "(using party(chat| chat))", "players");
                PropertyCondition.register(CondIsUsingAdminChat.class, "(using admin(chat| chat))", "players");
            }

        }
        //endregion
    }
}
