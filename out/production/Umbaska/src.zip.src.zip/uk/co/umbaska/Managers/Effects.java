package uk.co.umbaska.Managers;

import ch.njol.skript.Skript;
import ch.njol.skript.lang.ExpressionType;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.dynmap.DynmapAPI;

import uk.co.umbaska.ArmourStands.EffSpawnArmorStand;
import uk.co.umbaska.Bungee.EffChangeServer;
import uk.co.umbaska.Bungee.EffKickBungeePlayer;
import uk.co.umbaska.Bungee.EffSendBungeeMsg;
import uk.co.umbaska.Dynmap.EffSetVisOfPlayer;
import uk.co.umbaska.Factions.*;
import uk.co.umbaska.GattSk.Effects.*;
import uk.co.umbaska.GattSk.Effects.InventoryClick.EffSetClickedItem;
import uk.co.umbaska.GattSk.Effects.InventoryClick.EffSetCursorItem;
import uk.co.umbaska.GattSk.Effects.SimpleScoreboards.*;
import uk.co.umbaska.HologramBased.*;
import uk.co.umbaska.Main;
import uk.co.umbaska.Misc.EffSetCommandBlockInfo;
import uk.co.umbaska.Misc.EffTabList;
import uk.co.umbaska.Misc.NotVersionAffected.*;
import uk.co.umbaska.Misc.NotVersionAffected.Chunks.*;
import uk.co.umbaska.Misc.UM2_0.EffPotionEffectNoParticles;
import uk.co.umbaska.NametagEdit.EffSetNametag;
import uk.co.umbaska.NametagEdit.EffSetPrefix;
import uk.co.umbaska.NametagEdit.EffSetSuffix;
import uk.co.umbaska.PlaceHolderAPI.EffAddPlaceholder;
import uk.co.umbaska.PlaceHolderAPI.EffAddPlugin;
import uk.co.umbaska.ProtocolLib.*;
import uk.co.umbaska.Sound.EffPlayTrack;
import uk.co.umbaska.Spawner.*;
import uk.co.umbaska.System.*;
import uk.co.umbaska.Towny.EffSetPlotOwner;
import uk.co.umbaska.Towny.EffSetPlotPrice;
import uk.co.umbaska.UmbaskaCord.*;
import uk.co.umbaska.WorldEdit.*;
import uk.co.umbaska.mcMMO.EffSendAdminMesssage;
import uk.co.umbaska.mcMMO.EffSendPartyMessage;
@SuppressWarnings({ "unused", "deprecation" })
public class Effects {

    public static EntityHider enthider;
    public static Boolean enable_tag_features = Main.getInstance().getConfig().getBoolean("enable_tag_features");
    public static Boolean use_bungee = Main.getInstance().getConfig().getBoolean("use_bungee");
    public static Boolean forceGenTitleFeatures = Main.getInstance().getConfig().getBoolean("force-generate-title-features");
    public static Boolean forceGen18Features = Main.getInstance().getConfig().getBoolean("force-generate-18-features");
    public static Plugin dynmap;
    public static DynmapAPI api;
    public static Boolean debugInfo = Main.getInstance().getConfig().getBoolean("debug_info");

	private static String version = Register.getVersion();

    @SuppressWarnings("rawtypes")
	private static void registerNewEffect(String name, String cls, String syntax, Boolean multiversion){
        if (Skript.isAcceptRegistrations()){
            if (multiversion){
                Class newCls = Register.getClass(cls);
                if (newCls == null) {
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Effect for " + name + " due to Can't find Class!");
                    return;
                }
                registerNewEffect(name, newCls, syntax);
            }
            else{
                try {
                    registerNewEffect(name, Class.forName(cls), syntax);
                }catch (ClassNotFoundException e){
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Effect for " + name + " due to Wrong Spigot/Bukkit Version!");
                }
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Effect for " + name + " due to Skript Not Accepting Registrations");
        }
    }

    @SuppressWarnings("rawtypes")
	private static void registerNewEffect(String name, Class cls, String syntax){
        if (Skript.isAcceptRegistrations()){
            registerNewEffect(cls, syntax);
            if (debugInfo) {
                Bukkit.getLogger().info("Umbaska »»» Registered Effect for " + name + " with syntax \n" + syntax);
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Effect for " + name + " due to Skript Not Accepting Registrations");
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	private static void registerNewEffect(Class cls, String syntax){
        if (Skript.isAcceptRegistrations()){
            Skript.registerEffect(cls, syntax);
            if (debugInfo) {
                Bukkit.getLogger().info("Umbaska »»» Registered Effect for " + cls.getName() + " with syntax\n " + syntax);
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Effect for " + cls.getName() + " due to Skript Not Accepting Registrations");
        }
    }

    //I added some folding to this (Would only probably work on Intellij) -Headshot
    public static void runRegister(){

        //region PLOTME
        Plugin pl = Bukkit.getServer().getPluginManager().getPlugin("PlotSquared");
        Boolean registeredPlotSquared = false;
        if (pl != null) {
        	registeredPlotSquared = true;
            registerNewEffect(uk.co.umbaska.PlotSquared.EffPlotTeleport.class, "teleport %player% to %string%[ in %world%]");
            registerNewEffect(uk.co.umbaska.PlotSquared.EffClearPlot.class, "clear plot %string% in %world%");
            registerNewEffect(uk.co.umbaska.PlotSquared.EffMovePlot.class, "move %string% to %string% in %world%" );
            registerNewEffect(uk.co.umbaska.PlotSquared.EffDenyPlayer.class, "deny %player% from %string%" );
            registerNewEffect(uk.co.umbaska.PlotSquared.EffUnDeny.class,"allow %player% to %string%" );
            Skript.registerEffect(uk.co.umbaska.PlotSquared.EffToggleWorldEdit.class, new String[] { "set worldedit of %player% to %boolean%", "toggle worldedit of %player%", "enable worldedit of %player%", "disable worldedit of %player%" });
        }
        pl = Bukkit.getServer().getPluginManager().getPlugin("PlotMe");
        if (!registeredPlotSquared) {
        	if (pl != null) {
        		registerNewEffect(uk.co.umbaska.PlotMe.EffPlotTeleport.class, "teleport %player% to %string%[ in %world%]");
        		registerNewEffect(uk.co.umbaska.PlotMe.EffClearPlot.class, "clear plot %string% in %world%");
        		registerNewEffect(uk.co.umbaska.PlotMe.EffMovePlot.class, "move %string% to %string% in %world%" );
        		registerNewEffect(uk.co.umbaska.PlotMe.EffDenyPlayer.class, "deny %player% from %string%" );
        		registerNewEffect(uk.co.umbaska.PlotMe.EffUnDeny.class,"allow %player% to %string%" );
        	}
        }
        pl = Bukkit.getServer().getPluginManager().getPlugin("PlaceholderAPI");
        if (pl != null) {
        	Skript.registerEffect(EffAddPlaceholder.class, new String[] { "add [variable] %string% with [value] %string% to placeholders", "add [variable] %string% with [value] %string% using [plugin] %string% to placeholders" });
        	registerNewEffect(EffAddPlugin.class,"set plugin of %string% to %string% in placeholders");
        }
        
        //endregion
        //region NOTEBLOCKAPI (NEEDS FIXING)

        pl = Bukkit.getServer().getPluginManager().getPlugin("NoteBlockAPI");
        if (pl != null) {
            registerNewEffect(EffPlayTrack.class, "play (track|song|midi) %string% to %player%");
        }
        //endregion
        //region SPAWNER
        registerNewEffect(EffSetSpawner.class, "set spawner %location% to %string%");
        registerNewEffect(EffSetDelay.class, "set delay of %location% to %integer%");
        registerNewEffect(EffMFG_Drop.class, "drop a spawner at %location% based on %block%");
        registerNewEffect(EffMFG_GiveSpawner.class, "give a spawner to %player% based on %block%");
        registerNewEffect(EffMFG_SetSpawner.class, "set spawner at %location% to its type");
        //endregion
        //region TOWNY
        pl = Bukkit.getServer().getPluginManager().getPlugin("Towny");
        if (pl != null) {

            registerNewEffect(EffSetPlotOwner.class, "set owner of plot at %location% to %player%");
            registerNewEffect(EffSetPlotPrice.class, "set price of plot at %location% to %double%");

        }
        //endregion
        //endregion
        //region MISC/OTHER
        registerNewEffect(EffDropAll.class, "force drop inventory of %player% at %location%");

        registerNewEffect(EffCreateFile.class, "create [new] file %string%");
        registerNewEffect(EffDeleteFile.class, "(df|delete) [file] %string%");
        registerNewEffect(EffSetLine.class, "set line %integer% in [file] %string% to %string%");
        registerNewEffect(EffWriteToFile.class, "(write|wf) %string% to %string%)");

        registerNewEffect(EffWriteYAML.class, "write %string% with [value] %string% to %string%");
        registerNewEffect(EffCopy.class, "copy file %string% to %string%");
        registerNewEffect(EffCopyDir.class, "copy (d|dir|dire|directory) %string% to %string%");

        registerNewEffect(EffLoadScript.class, "load script[s] from [folder] %string%");
        //commandblock stuff
        Skript.registerEffect(EffSetCommandBlockInfo.class, new String[] {"set command of %block% to %string%" , "set name of %block% to %string%"});
        //endregion
        //region PROTCOLLIB
        pl = Bukkit.getServer().getPluginManager().getPlugin("ProtocolLib");
        if (pl != null) {

            Bukkit.getLogger().info("Loading ProtocolLib Effects");

            enthider = new EntityHider(Main.getInstance(), EntityHider.Policy.BLACKLIST);

            registerNewEffect(EffHideEntity.class, "protocol hide %entity% from %players%");
            registerNewEffect(EffShowEntity.class, "protocol show %entity% to %players%");
            registerNewEffect(EffToggleVisibility.class, "toggle visibility of %entity% for %players%");
            Skript.registerExpression(ExprCanSee.class, Boolean.class, ExpressionType.PROPERTY, "visibility of %entity% for %player%");

            //region Disguises
            registerNewEffect("Disguise", "ProtocolLib.Disguises.EffDisguiseAsEntity", "disguise %entity% as %entitydisguise% [with custom name %-string%]", true);
            registerNewEffect("Disguise", "ProtocolLib.Disguises.EffDisguiseAsPlayer", "disguise %entity% as player %string%", true);
            registerNewEffect("Undisguise", "ProtocolLib.Disguises.EffUndisguise", "undisguise %entity%", true);
            //endregion

            //registerNewEffect(EffDisguise.class, "disguise %entity% as %string%");
            //registerNewEffect(EffDisguiseName.class, "disguise %entity% as %string% with custom name %string%");
            //registerNewEffect(EffOLDUndisguise.class, "undisguise %entity%");

        }
        //endregion
        //region UMBASKAAPI
        pl = Bukkit.getServer().getPluginManager().getPlugin("UmbaskaAPI");
        if (pl != null) {

            registerNewEffect(EffImgInChat.class,  "show %player% image %string% with %string%, %string%, %string%");
            registerNewEffect(EffImgFromURL.class,  "show %player% image from %string% with %string%, %string%, %string%");

        }
        //endregion
        //region NAMETAGEDIT
        pl = Bukkit.getServer().getPluginManager().getPlugin("NametagEdit");

        if (pl != null) {
            if (enable_tag_features == true) {
                registerNewEffect(EffSetPrefix.class,  "set prefix of %player% to %string%");
                registerNewEffect(EffSetSuffix.class,  "set suffix of %player% to %string%");
                registerNewEffect(EffSetNametag.class,  "set name tag of %player% to %string% and %string%");
            }
        }
        //endregion
        //region DYNMAP
        pl = Bukkit.getServer().getPluginManager().getPlugin("Dynmap");
        if (pl != null) {
		 /*
		  *  Dynmap - Other
		  */
            PluginManager pm = Bukkit.getServer().getPluginManager();
            dynmap = pm.getPlugin("Dynmap");
            api = (DynmapAPI) dynmap;
            if (api == null) {
                Main.getInstance().getLogger().info(ChatColor.RED + "[Umbaska] Damn son! There was a problem hooking into Dynmap. Sorry dude.");
            }
            else {

                registerNewEffect(EffSetVisOfPlayer.class, "set Dynmap visibility of %player% to %boolean%" );
            }

        }
        //endregion
        //region FACTIONS
        if (!Main.disableSkRambled) {
            pl = Bukkit.getServer().getPluginManager().getPlugin("MassiveCore");
            if (pl != null) {
                pl = Bukkit.getServer().getPluginManager().getPlugin("Factions");
                if (pl != null) {

                    registerNewEffect(EffUnClaimLand.class,
                            "unclaim [faction] land at %location%");
                    registerNewEffect(EffClaimLand.class,
                            "claim land for [the] [faction] %faction% at %location%");
                    registerNewEffect(EffInvitePlayer.class,
                            "invite %player% to [the] [faction] %faction%");
                    registerNewEffect(EffKickPlayer.class,
                            "remove %player% from [the] [faction] %faction%");
                    registerNewEffect(EffDisbandFaction.class,
                            "disband [the] [faction] %faction%");
                    registerNewEffect(EffCreateFaction.class, "create a faction [with name] %string% with leader %player%");
                }
            }
            //endregion
            //region MCMMO
            pl = Bukkit.getServer().getPluginManager().getPlugin("mcMMO");
            if (pl != null) {
                registerNewEffect(EffSendPartyMessage.class, "send %string% to [the] party %party% from [a] player named %string%");

                registerNewEffect(EffSendAdminMesssage.class, "send %string% to [the] admin[chat| chat] from [a] player named %string%");
            }
            //endregion
            //region WORLDEDIT
        }
        pl = Bukkit.getServer().getPluginManager().getPlugin("WorldEdit");
        if (pl != null){
            registerNewEffect(EffPasteSchematic.class, "[umbaska] paste schematic %string% at %location%");
            registerNewEffect(EffPasteSchematicNoAir.class, "[umbaska] paste schematic %string% at %location% (ignoring air|with no air)");
            registerNewEffect(EffPlaceSchematic.class, "[umbaska] place schematic %string% at %location%");
            registerNewEffect(EffPlaceSchematicNoAir.class, "[umbaska] place schematic %string% at %location% (ignoring|with no) air");
            registerNewEffect(EffSaveSchematic.class, "save schematic %string% based (off of|on) %player%['s selection]");
        }
        //endregion
        //region WORLDEDIT
        registerNewEffect(EffRemoveExplodedBlock.class, "(remove|delete) %block% from [better][ ][new] exploded blocks");
        registerNewEffect(EffClearExplodedBlocks.class, "(remove|delete|clear) all [better] exploded blocks");
        //endregion
        //region SCOREBOARDS
        registerNewEffect(EffNewScoreboard.class, "create [a] new scoreboard [named] %string%");
        registerNewEffect(EffSetPlayerScoreboard.class, "set scoreboard of %players% to %string%");
        registerNewEffect(EffSetScore.class, "set value of score %string% (for|in) [score][board] %string% objective %string% to %number%");
        registerNewEffect(EffResetScore.class, "reset [value] [of] score %string% (for|in) [score][board] %string%");
        registerNewEffect(EffNewObjective.class, "create [a] [new] %string% objective for [score][board] %string% (called|named) %string%");
        registerNewEffect(EffSetObjectiveDisplay.class, "set objective display slot for [objective] %string% in [score][board] %string% to %string%");
        registerNewEffect(EffSetObjectiveName.class, "set objective display name for [objective] %string% in [score][board] %string% to %string%");
        registerNewEffect(EffUnregisterObjective.class, "unregister objective %string% in [score][board] %string%");
        registerNewEffect(EffDeleteScoreboard.class, "delete score[ ]board %string%");
        registerNewEffect(EffCreateTeam.class, "create team %string% in [score][board] %string%");
        registerNewEffect(EffTeamPlayer.class, "(remove|add) [player] %offlineplayer% (from|to) team %string% in [score][board] %string%");
        registerNewEffect(EffSetTeamPrefix.class, "set (suffix|prefix) for team %string% in [score][board] %string% to %string%");
        registerNewEffect(EffSetTeamFF.class, "set friendly fire for team %string% in [score][board] %string% to %boolean%");
        registerNewEffect(EffSetTeamSeeInvis.class, "set see friendly invisibles for team %string% in [score][board] %string% to %boolean%");
        registerNewEffect("Open Inventory", "Misc.EffOpenInventory", "open %umbaskainv% [named %-string%] to %player%", true);
        registerNewEffect("Open Inventory", "Misc.EffOpenInventoryClose", "open %umbaskainv% [named %-string%] to %player% (that closes|to close)", true);
        registerNewEffect(EffOpenInventoryRows.class, "open %umbaskainv% [named %-string%] with %integer% rows to %player%");
        //endregion
        //region WORLD MANAGER
        registerNewEffect(EffCreateWorld.class, "create [a] new world [name[d]] %string%");

        registerNewEffect(EffDeleteWorld.class, "delete world %string%");

        registerNewEffect(EffUnloadWorld.class, "unload world %string%");

        registerNewEffect(EffLoadWorld.class, "load world %string%");

        registerNewEffect(EffCreateWorldFrom.class, "create world named %string% from [folder] %string%");
        //endregion
        //region MISC2

        registerNewEffect(EffLoadChunk.class, "load chunk at %location%");
        registerNewEffect(EffUnloadChunk.class, "unload chunk at %location%");
        registerNewEffect(EffGenerateChunk.class, "generate chunk at %location%");
        registerNewEffect(EffLoadChunkC.class, "load chunk at %chunk%");
        registerNewEffect(EffUnloadChunkC.class, "unload chunk at %chunk%");
        registerNewEffect(EffGenerateChunkC.class, "generate chunk at %chunk%");

        registerNewEffect(EffUpdateInventory.class, "update inventory of %player%");
        registerNewEffect(EffResetRecipes.class, "reset all [server] recipes");

        registerNewEffect(EffNothing_MFG.class, "do nothing");
        //endregion
        //region TEMPORARY HOLOGRAMS
        registerNewEffect(EffCreateHologram.class, "create [a ]new holo[gram] named %string%");
        registerNewEffect(EffSetHoloLine.class, "set holo[gram] line %integer% of holo[gram] %string% to %string%");

        registerNewEffect(EffAddHoloLine.class, "set lines of holo[gram] %string% to %strings%");
        registerNewEffect(EffDeleteHoloLine.class, "(remove|clear|delete) lines of holo[gram] %string%");
        registerNewEffect(EffMoveHolo.class, "move holo[gram] %string% to %location%");
        registerNewEffect(EffHoloFollow.class, "make holo[gram] %string% follow %entity%");
        registerNewEffect(EffHoloStart.class, "start holo[gram] %string%");
        registerNewEffect(EffHoloStop.class, "stop holo[gram] %string%");
        registerNewEffect(EffDeleteHolo.class, "delete holo[gram] %string%");

        registerNewEffect(EffCreateFollowGram.class, "create [a ]new following holo[gram] (to|that) follow[s] %entity% with [text] %strings%");

        registerNewEffect(EffSetHoloType.class, "set holo[gram] type to (0¦wither skull[s]|1¦armor stand[s])");

        registerNewEffect(EffPlayerBreak.class, "make %player% break [block] at %location%");
        registerNewEffect(EffPlayerBreakTool.class, "make %player% break [block] at %location% using [tool] %itemstack%");

        registerNewEffect(EffNewSimpleScoreboard.class, "create [a] new simple scoreboard [named] %string%");
        registerNewEffect(EffSetSlot.class, "set slot %number% of simple [score][board] %string% to %string%");
        registerNewEffect(EffSetTitle.class, "set [display] title of simple [score][ ][board] %string% to %string%");
        registerNewEffect(EffShowBoard.class, "set simple [score][board] of %players% to %string%");
        registerNewEffect(EffClearSlot.class, "clear slot %number% of simple [score][board] %string%");
        registerNewEffect(EffDeleteBoard.class, "delete simple [score][ ][board] %string%");
        //endregion
        //region MISC3
        registerNewEffect(EffMon3.class, "mon3");
        registerNewEffect(EffRav3.class, "rav3");

        registerNewEffect(EffSetCursorItem.class, "set cursor item to %itemstack%");
        registerNewEffect(EffSetClickedItem.class, "set clicked item to %itemstack%");

        registerNewEffect(EffSetItemInEntity.class, "set [umbaska] item[s] within %entity% to %itemstack%");
        registerNewEffect(EffRemoveAllPotionEffects.class, "remove all potion effects from %entity%");

        registerNewEffect(EffScatter.class, "scatter %entities% around %integer%(,| and) %integer% [in] [world] %world% (with|for) rad[ius] of %integer% [ignoring %-itemstacks%] [with delay of %-integer% [between teleports]]");

        registerNewEffect(EffPotionEffectNoParticles.class, "apply [potion of] %potioneffecttype% [potion] [[[of] tier] %-number%] to %livingentities% for %timespan% (and|to) hide [particle[ effects]]");

        if (!Main.getInstance().getConfig().contains("force-generate-title-features")){
            Main.getInstance().getConfig().set("force-generate-title-features", false);
            forceGenTitleFeatures = false;
        }
        registerNewEffect(EffPlaceDroppedItem.class, "place %itemstack% at %location%");

        registerNewEffect("Clear Bounding Box", "ArmourStands.EffClearHitbox", "clear hitbox of %entity%", true); //Don't use this. It probably crashes your game

        registerNewEffect("Set Attribute", "Attributes.EffSetAttribute", "set [entity] attribute %entityattributes% of %entity% to %number%", true);

        registerNewEffect("Title", "Misc.EffSendTitle", "send [a ]title from %string% and %string% to %players% for %number%, %number%, %number%", true);
        registerNewEffect("Action Bar", "Misc.EffActionBar", "send [a ]action bar from %string% to %players%", true);
        registerNewEffect(EffTabList.class, "(send|set) [advanced ](0¦footer|1¦header) to %string% (to|for) %players%");
        Main.getInstance().getLogger().info("It appears you might be using a 1.8 Build! I'm going to attempt to register some things related to it :)");
        registerNewEffect(EffSpawnArmorStand.class, "[umbaska] spawn [a][n] (armour|armor) stand at %locations%");
        registerNewEffect("Trail Entity", "Misc.EffTrailEntity", "[umbaska] trail %entities% with [%number% of ]%particleenum%[:%number%] [[ with] data %number%] [[(with|and)] secondary data %number%]", true);

        registerNewEffect(EffPlayEntityEffect.class, "play [entity] [effect] %entityeffect% (for|on|at) %entity%");

        Main.getInstance().getLogger().info("[Umbaska > SkQuery] Attempting to register new Spawn Particle Effect.");
        registerNewEffect("Better Particle", "Replacers.EffParticle", "[(1.8|Umbaska|skquery isnt updated)] (summon|play|create|activate|spawn) %number% [of] %particleenum%[:%number%] [offset (at|by|from) %number%, %number%(,| and) %number%] at %locations% (to|for) %players% [[ with] data %number%] [[(with|and)] secondary data %number%]", true);
        registerNewEffect("Better Particle All", "Replacers.EffParticleAll", "[(1.8|Umbaska|skquery isnt updated)] (summon|play|create|activate|spawn) %number% [of] %particleenum%[:%number%] [offset (at|by|from) %number%, %number%(,| and) %number%] at %locations% [[ with] data %number%] [[(with|and)] secondary data %number%]", true);
        registerNewEffect("Better Effect", "Replacers.EffBukkitEffect", "(summon|play|create|activate|spawn) [bukkit] [effect] %bukkiteffect% at %locations% to %players% [[with] [data] %integer%] [[(with|and)] secondary data %integer%]", true);
        registerNewEffect("Better Effect All", "Replacers.EffBukkitEffectAll", "(summon|play|create|activate|spawn) [bukkit] [effect] %bukkiteffect% at %locations% [[with] [data] %integer%] [[(with|and)] secondary data %integer%]", true);
        //endregion
        //region UMBASKACORD
		if (Main.usingUmbaskaCord){
			registerNewEffect(EffUpdateKey.class, "[force ]update [global ]key %string%");
            registerNewEffect(EffDefineGlobalVariable.class, "define global variable %string%");
			registerNewEffect(EffSetBungeeIcon.class, "set Bungee server icon to [url] %string%");
			registerNewEffect(EffSetBungeeMOTD.class, "set Bungee motd to %string%");
			registerNewEffect(EffSetBungeePlayerList.class, "set Bungee player list to %string%");
            registerNewEffect(EffSendBungeeTitle.class, "send [a ] Bungee[ ][cord] title from %string% and %string% to %string% for %number%, %number%, %number%");
            registerNewEffect(EffSendBungeeTitleAll.class, "send [a ] Bungee[ ][cord] title from %string% and %string% to (all|every(body| player)) for %number%, %number%, %number%");
		}
        //endregion
        //region BUNGEE
        if (use_bungee) {
            registerNewEffect(EffChangeServer.class, "send %player% to [server] %string%");
            registerNewEffect(EffKickBungeePlayer.class, "Bungee[ ][cord] kick %string% (due to|for) [reason] %string%");
            registerNewEffect(EffSendBungeeMsg.class, "Bungee[ ][cord] (send|tell|message) %string% to %string%");
            registerNewEffect(EffSendBungeeMsg.class, "Bungee[ ][cord] (broadcast|[send ]alert)%string%");
        }
        //endregion
        //region PACKET PLAYERS

        registerNewEffect("Register Player", "ProtocolLib.FakePlayer.EffRegisterNewFakePlayer", "register new fake player [with id] %string%", true);
        registerNewEffect("Set Display Name Fake player", "ProtocolLib.FakePlayer.EffSetDisplayedName", "set displayed name of fake player %string% to %string%", true);
        registerNewEffect("Set location fake player", "ProtocolLib.FakePlayer.EffSetLocation", "set location of fake player %string% to %location%", true);
        registerNewEffect("Set Skin fake player", "ProtocolLib.FakePlayer.EffSetSkin", "set skin of fake player %string% to %string%", true);
        //endregion
    }
}
