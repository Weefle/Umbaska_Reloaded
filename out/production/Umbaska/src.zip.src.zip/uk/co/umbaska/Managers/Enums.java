package uk.co.umbaska.Managers;

import ca.thederpygolems.armorequip.ArmourEquipEvent;
import ch.njol.skript.Skript;
import ch.njol.skript.classes.ClassInfo;
import ch.njol.skript.classes.Parser;
import ch.njol.skript.expressions.base.EventValueExpression;
import ch.njol.skript.lang.ParseContext;
import ch.njol.skript.registrations.Classes;
import com.gmail.nossr50.datatypes.party.Party;
import com.gmail.nossr50.datatypes.skills.SkillType;
import com.gmail.nossr50.party.PartyManager;
import com.massivecraft.factions.Rel;
import com.massivecraft.factions.entity.Faction;
import com.massivecraft.factions.entity.FactionColl;
import com.sk89q.worldguard.bukkit.WGBukkit;
import com.sk89q.worldguard.protection.flags.DefaultFlag;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.Bukkit;
import org.bukkit.EntityEffect;
import org.bukkit.World;
import org.bukkit.block.banner.PatternType;
import org.bukkit.event.inventory.ClickType;
import uk.co.umbaska.Enums.BukkitEffectEnum;
import uk.co.umbaska.Enums.InventoryTypes;
import uk.co.umbaska.Enums.Operation;
import uk.co.umbaska.Enums.ParticleEnum;
import uk.co.umbaska.Main;
import uk.co.umbaska.Misc.Date.DayOfWeek;
import uk.co.umbaska.Utils.Disguise.EntityDisguise;
import uk.co.umbaska.Utils.EnumClassInfo;

import javax.annotation.Nullable;
import java.util.Locale;

/**
 * Created by Zachary on 5/25/2015.
 */
@SuppressWarnings("rawtypes")
public class Enums {
    public static Boolean debugInfo = Main.getInstance().getConfig().getBoolean("debug_info");
    private static String version = Register.getVersion();

    private static void registerEnum(String cls, String name, Boolean multiversion) {
        if (Skript.isAcceptRegistrations()) {
            if (multiversion) {
                
				Class newCls = Register.getClass(cls);
                if (newCls == null) {
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Enum for " + name + " due to \nWrong Spigot/Bukkit Version!");
                }
                if (debugInfo) {
                    Bukkit.getLogger().info("Umbaska »»» Registered Enum for " + name + " for Version " + version);
                }
                registerEnum(newCls, name);
            } else {
                try {
                    registerEnum(Class.forName(cls), name);
                } catch (ClassNotFoundException e) {
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Enum for " + name + " due to \nWrong Spigot/Bukkit Version!");
                }
            }
        }else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Enum for " + name + " due to \nSkript Not Accepting Registrations");
        }
    }
    @SuppressWarnings("unchecked")
	private static void registerEnum(Class cls, String name) {
        if (Skript.isAcceptRegistrations()) {
            EnumClassInfo.create(cls, name).register();
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Enum for " + name + " due to \nSkript Not Accepting Registrations");
        }
    }
    @SuppressWarnings({ "unchecked", "unused" })
    private static void registerEnum(Class cls, String name, EventValueExpression defaultExpression) {
        if (Skript.isAcceptRegistrations()) {
            EnumClassInfo.create(cls, name, defaultExpression).register();
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Enum for " + name + " due to \nSkript Not Accepting Registrations");
        }
    }

    public static void runRegister(){
        registerEnum(InventoryTypes.class, "umbaskainv");
        registerEnum(ParticleEnum.class, "particleenum");
        registerEnum(BukkitEffectEnum.class, "bukkiteffect");
        registerEnum("Enums.Attributes", "entityattribute", true);
	    registerEnum(Locale.class, "locale");
	    registerEnum(DayOfWeek.class, "dayofweek");
	    registerEnum(PatternType.class, "bannerpattern");
        registerEnum(EntityDisguise.class, "entitydisguise");
        registerEnum(Operation.class, "nbtoperation");
        registerEnum(ArmourEquipEvent.EquipMethod.class, "equipmethod");
        registerEnum(ClickType.class, "clicktype");
        registerEnum(EntityEffect.class, "entityeffect");
        //registerEnum(PlayerResourcePackStatusEvent.Status.class, "resourcepackresponse");
        //region FACTIONS
        if (!Main.disableSkRambled) {
            if (Bukkit.getPluginManager().getPlugin("Factions") != null && Bukkit.getPluginManager().getPlugin("MassiveCore") != null) {
                Classes.registerClass(new ClassInfo<Faction>(Faction.class, "faction")
                        .user("faction")
                        .name("Faction")
                        .defaultExpression(
                                new EventValueExpression<Faction>(Faction.class))
                        .parser(new Parser<Faction>() {
                            @Override
                            @Nullable
                            public Faction parse(String s, ParseContext context) {
                                return FactionColl.get().getByName(s);
                            }

                            @Override
                            public String toString(Faction faction, int flags) {
                                return faction.getName().toLowerCase();
                            }

                            @Override
                            public String toVariableNameString(Faction faction) {
                                return faction.getName().toLowerCase();
                            }

                            @Override
                            public String getVariableNamePattern() {
                                return ".+";
                            }

                        }));
                Classes.registerClass(new ClassInfo<Rel>(Rel.class, "rel").name("Rel")
                        .parser(new Parser<Rel>() {
                            @Override
                            @Nullable
                            public Rel parse(String s, ParseContext context) {
                                return Rel.parse(s);
                            }

                            @Override
                            public String toString(Rel rel, int flags) {
                                return rel.toString().toLowerCase();
                            }

                            @Override
                            public String toVariableNameString(Rel rel) {
                                return rel.toString().toLowerCase();
                            }

                            @Override
                            public String getVariableNamePattern() {
                                return ".+";
                            }

                        }));
                //endregion
            }
            //region MCMMO
            if (Bukkit.getPluginManager().getPlugin("mcMMO") != null) {
                Classes.registerClass(new ClassInfo<Party>(Party.class, "party").name(
                        "Party").parser(new Parser<Party>() {
                    @Override
                    @Nullable
                    public Party parse(String s, ParseContext context) {
                        return PartyManager.getParty(s);
                    }

                    @Override
                    public String toString(Party party, int flags) {
                        return party.getName().toLowerCase();
                    }

                    @Override
                    public String toVariableNameString(Party party) {
                        return party.getName().toLowerCase();
                    }

                    @Override
                    public String getVariableNamePattern() {
                        return ".+";
                    }

                }));

                Classes.registerClass(new ClassInfo<SkillType>(SkillType.class, "skill")
                        .name("Skill").parser(new Parser<SkillType>() {
                            @Override
                            @Nullable
                            public SkillType parse(String s, ParseContext context) {
                                try {

                                    return SkillType.valueOf(s.toUpperCase());
                                } catch (Exception e) {

                                }
                                return null;
                            }

                            @Override
                            public String toString(SkillType skill, int flags) {
                                return skill.getName().toLowerCase();
                            }

                            @Override
                            public String toVariableNameString(SkillType skill) {
                                return skill.getName().toLowerCase();
                            }

                            @Override
                            public String getVariableNamePattern() {
                                return ".+";
                            }

                        }));
            }
            //endregion
            //region WORLDGUARD
            if (Bukkit.getPluginManager().getPlugin("WorldGuard") != null) {
                Classes.registerClass(new ClassInfo<ProtectedRegion>(
                        ProtectedRegion.class, "protectedregion")
                        .name("Protected Region")
                        .user("protectedregions?")
                        .defaultExpression(
                                new EventValueExpression<ProtectedRegion>(
                                        ProtectedRegion.class))
                        .parser(new Parser<ProtectedRegion>() {
                            @Override
                            @Nullable
                            public ProtectedRegion parse(String s, ParseContext context) {
                                for (World w : Bukkit.getServer().getWorlds()) {
                                    if (WGBukkit.getRegionManager(w).hasRegion(s))
                                        return WGBukkit.getRegionManager(w)
                                                .getRegion(s);
                                }
                                return null;
                            }

                            @Override
                            public String toString(ProtectedRegion region, int flags) {
                                return region.getId().toLowerCase();
                            }

                            @Override
                            public String toVariableNameString(ProtectedRegion region) {
                                return region.getId().toLowerCase();
                            }

                            @Override
                            public String getVariableNamePattern() {
                                return ".+";
                            }

                        }));
                Classes.registerClass(new ClassInfo<Flag>(Flag.class, "flag")
                        .name("Flag")
                        .user("flags?")
                        .defaultExpression(
                                new EventValueExpression<Flag>(
                                        Flag.class))
                        .parser(new Parser<Flag<?>>() {
                            @Override
                            public Flag<?> parse(String s, ParseContext context) {
                                return DefaultFlag.fuzzyMatchFlag(s);
                            }

                            @Override
                            public String toString(Flag<?> flag, int flags) {
                                return flag.getName().toLowerCase();
                            }

                            @Override
                            public String toVariableNameString(Flag<?> flag) {
                                return flag.getName().toLowerCase();
                            }

                            @Override
                            public String getVariableNamePattern() {
                                return ".+";
                            }

                        }));
            }
            //endregion
            //Classes.registerClass(new ClassInfo<>(BannerLayer.class, "bannerlayer")
            //        .parser(new Parser<BannerLayer>() {
            //            @Override
            //            public BannerLayer parse(String s, ParseContext parseContext) {
            //                return null;
            //            }
//
            //            @Override
            //            public boolean canParse(ParseContext context) {
            //                return false;
            //            }
//
            //            @Override
            //            public String toString(BannerLayer layer, int i) {
            //                return layer.serialize();
            //            }
//
            //            @Override
            //            public String toVariableNameString(BannerLayer layer) {
            //                return layer.serialize();
            //            }
//
            //            @Override
            //            public String getVariableNamePattern() {
            //                return ".+";
            //            }
            //        }));
        }
        Main.getInstance().getLogger().info("[Umbaska > SkQuery] Registered Custom Particle Enum. Have some BACON!!!!");
    }
}
