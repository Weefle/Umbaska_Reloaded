package uk.co.umbaska.Managers;

import ch.njol.skript.Skript;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.skript.lang.ExpressionType;

import com.massivecraft.factions.Rel;
import com.massivecraft.factions.entity.Faction;
import com.palmergames.bukkit.towny.object.Town;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.banner.Pattern;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scoreboard.Objective;
import org.bukkit.util.Vector;

import uk.co.umbaska.ArmourStands.Arms.*;
import uk.co.umbaska.ArmourStands.*;
import uk.co.umbaska.ArmourStands.Legs.*;
import uk.co.umbaska.Bungee.*;
import uk.co.umbaska.Dynmap.ExprVisOfPlayer;
import uk.co.umbaska.Factions.*;
import uk.co.umbaska.GattSk.Expressions.*;
import uk.co.umbaska.Main;
import uk.co.umbaska.MathsExpressions.*;
import uk.co.umbaska.Misc.Banners.ExprBannerLayer;
import uk.co.umbaska.Misc.Banners.ExprNewBannerFrom;
import uk.co.umbaska.Misc.Banners.ExprNewLayer;
import uk.co.umbaska.Misc.Date.*;
import uk.co.umbaska.Misc.ExprCommandBlockInfo;
import uk.co.umbaska.Misc.ExprEnchantsOfItem;
import uk.co.umbaska.Misc.ExprLoopAllBlocks;
import uk.co.umbaska.Misc.ExprLoopSolidBlocks;
import uk.co.umbaska.Misc.ExprLoopTransparentBlocks;
import uk.co.umbaska.Misc.NotVersionAffected.*;
import uk.co.umbaska.Misc.UM2_0.*;
import uk.co.umbaska.NametagEdit.ExprGetNametag;
import uk.co.umbaska.NametagEdit.ExprGetPrefix;
import uk.co.umbaska.NametagEdit.ExprGetSuffix;
import uk.co.umbaska.ParticleProjectiles.Expressions.ExprSimpleVector;
import uk.co.umbaska.PlaceHolderAPI.EffParse;
import uk.co.umbaska.ProtocolLib.ExprCanSee;
import uk.co.umbaska.Spawner.ExprDelayTime;
import uk.co.umbaska.Spawner.ExprItemName;
import uk.co.umbaska.Spawner.ExprSpawnedType;
import uk.co.umbaska.System.*;
import uk.co.umbaska.Towny.*;
import uk.co.umbaska.UUID.ExprNamesOfPlayer;
import uk.co.umbaska.UUID.ExprUUIDOfEntity;
import uk.co.umbaska.UmbaskaCord.ExprGlobalKey;
import uk.co.umbaska.WorldEdit.ExprAllSchematics;
import uk.co.umbaska.mcMMO.ExprPowerLevelOfPlayer;

import java.util.Date;
import java.util.UUID;
@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class Expressions {
    public static Boolean use_bungee = Main.getInstance().getConfig().getBoolean("use_bungee");
    public static Boolean debugInfo = Main.getInstance().getConfig().getBoolean("debug_info");
    
	private static void registerNewSimpleExpression(String name, String cls, Class returnType, String syntax1, String syntax2, Boolean multiversion){
        if (Skript.isAcceptRegistrations()){
            if (multiversion){
                Class newCls = Register.getClass(cls);
                if (newCls == null) {
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Can't find Class!");
                    return;
                }
                if (debugInfo) {
                    Bukkit.getLogger().info("Umbaska »»» Registered Expression for " + name + " with syntax\n set " + syntax1 + " of " + syntax2 + " for Version " + Register.getVersion());
                }
                SimplePropertyExpression.register(newCls, returnType, syntax1, syntax2);
            }
            else{
                Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Wrong Spigot/Bukkit Version!");
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Skript Not Accepting Registrations");
        }
    }
    
	private static void registerNewExpression(String name, String cls, Class returnType, ExpressionType expressionType, String syntax, Boolean multiversion){
        if (Skript.isAcceptRegistrations()){
            if (multiversion){
                Class newCls = Register.getClass(cls);
                if (newCls == null) {
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Can't find Class!");
                    return;
                }
                if (debugInfo) {
                    Bukkit.getLogger().info("Umbaska »»» Registered Expression for " + name + " with syntax\n " + syntax + " for Version " + Register.getVersion());
                }
                registerNewExpression(name, newCls, returnType, expressionType, syntax);
            }
            else{
                try {
                    registerNewExpression(name, Class.forName(cls), returnType, expressionType, syntax);
                }catch (ClassNotFoundException e){
                    Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Wrong Spigot/Bukkit Version!");
                }
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Skript Not Accepting Registrations");
        }
    }
    private static void registerNewExpression(String name, Class cls, Class returnType, ExpressionType expressionType, String... syntaxes){
        if (Skript.isAcceptRegistrations()){
            registerNewExpression(cls, returnType, expressionType, syntaxes);
            if (debugInfo) {
                for (String syntax : syntaxes) {
                    Bukkit.getLogger().info("Umbaska »»» Registered Expression for " + name + " with syntax \n" + syntax);
                }
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + name + " due to Skript Not Accepting Registrations");
        }
    }
    private static void registerNewExpression(Class cls, Class returnType, ExpressionType expressionType, String... syntaxes){
        if (Skript.isAcceptRegistrations()){
            Skript.registerExpression(cls, returnType, expressionType, syntaxes);
            if (debugInfo) {
                for (String syntax : syntaxes) {
                    Bukkit.getLogger().info("Umbaska »»» Registered Expression for " + cls.getName() + " with syntax\n " + syntax);
                }
            }
        }
        else{
            Bukkit.getLogger().info("Umbaska »»» Can't Register Expression for " + cls.getName() + " due to Skript Not Accepting Registrations");
        }
    }
    public static void runRegister(){
        //region PLOTME and PLOTSQUARED
        Plugin pl = Bukkit.getServer().getPluginManager().getPlugin("PlotSquared");
        Boolean registeredPlotSquared = false;
        if (pl != null) {
        	registeredPlotSquared = true;
            registerNewExpression(uk.co.umbaska.PlotSquared.ExprPlotAtPlayer.class, String.class, ExpressionType.PROPERTY, "plot at %player%");
            registerNewExpression(uk.co.umbaska.PlotSquared.ExprPlotAtLoc.class, String.class, ExpressionType.PROPERTY, "plot at location %location%");
            registerNewExpression(uk.co.umbaska.PlotSquared.ExprGetOwner.class, String.class, ExpressionType.PROPERTY, "[get ]owner of %string%");
            registerNewExpression(uk.co.umbaska.PlotSquared.ExprGetPlayerPlots.class, String.class, ExpressionType.PROPERTY, "plots of %player%");
            registerNewExpression(uk.co.umbaska.PlotSquared.ExprTopCorner.class, Location.class, ExpressionType.PROPERTY, "(top|upper) corner of %string% in %world%");
            registerNewExpression(uk.co.umbaska.PlotSquared.ExprBottomCorner.class, Location.class, ExpressionType.PROPERTY, "(bottom|lower) corner of %string% in %world%");
        }      
        if (registeredPlotSquared == false) {
        	pl = Bukkit.getServer().getPluginManager().getPlugin("PlotMe");
        	if (pl != null) {
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprPlotAtPlayer.class, String.class, ExpressionType.PROPERTY, "plot at %player%");
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprPlotAtLoc.class, String.class, ExpressionType.PROPERTY, "plot at location %location%");
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprGetOwner.class, String.class, ExpressionType.PROPERTY, "[get ]owner of %string%");
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprGetPlayerPlots.class, String.class, ExpressionType.PROPERTY, "plots of %player%");
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprGetPlayerPlots.class, String.class, ExpressionType.PROPERTY, "plots of %player%");
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprTopCorner.class, Location.class, ExpressionType.PROPERTY, "(top|upper) corner of %string% in %world%");
        		registerNewExpression(uk.co.umbaska.PlotMe.ExprBottomCorner.class, Location.class, ExpressionType.PROPERTY, "(bottom|lower) corner of %string% in %world%");
        	}
        }
        Bukkit.broadcastMessage("registeredPlotSquared: " + registeredPlotSquared);
        //endregion
        //region TOWNY
        pl = Bukkit.getServer().getPluginManager().getPlugin("Towny");
        if (pl != null) {
            registerNewExpression(ExprTownAtPlayer.class, String.class, ExpressionType.PROPERTY, "town at %player%");
            registerNewExpression(ExprTownOfPlayer.class, Town.class, ExpressionType.PROPERTY, "town of %player%");
            registerNewExpression(ExprTDBank.class, Double.class, ExpressionType.PROPERTY, "town balance of %string%");
            registerNewExpression(ExprTDPlayerCount.class, Integer.class, ExpressionType.PROPERTY, "player[ ]count of %string%");
            registerNewExpression(ExprTDPlayers.class, String.class, ExpressionType.PROPERTY, "players of %string%");
            registerNewExpression(ExprTDTaxes.class, Double.class, ExpressionType.PROPERTY, "town taxes of %string%");
            registerNewExpression(ExprPlotOwner.class, String.class, ExpressionType.PROPERTY, "owner of plot at %location%");
            registerNewExpression(ExprPlotPrice.class, Double.class, ExpressionType.PROPERTY, "price of plot at %location%");
            registerNewExpression(ExprRDLastOnline.class, String.class, ExpressionType.PROPERTY, "resident data last online of %player%");
            registerNewExpression(ExprRDLastOnlineDate.class, String.class, ExpressionType.PROPERTY, "resident data last online date of %player%");
            registerNewExpression(ExprRDChatName.class, String.class, ExpressionType.PROPERTY, "resident data chat name of %player%");
            registerNewExpression(ExprRDFriends.class, String.class, ExpressionType.PROPERTY, "resident data friends of %player%");
            registerNewExpression(ExprRDNationRanks.class, String.class, ExpressionType.PROPERTY, "resident data nation ranks of %player%");
            registerNewExpression(ExprRDRegistered.class, Long.class, ExpressionType.PROPERTY, "resident data registered of %player%");
            registerNewExpression(ExprRDSurname.class, String.class, ExpressionType.PROPERTY, "resident data surname of %player%");
            registerNewExpression(ExprRDTitle.class, String.class, ExpressionType.PROPERTY, "resident data title of %player%");
        }
        //endregion
        //region UUID
        registerNewExpression(ExprNamesOfPlayer.class, String.class, ExpressionType.COMBINED, "names of %string%");
        if (!Main.getInstance().getConfig().isSet("entity_uuid_fix")){
            Main.getInstance().getConfig().set("entity_uuid_fix", false);
        }
        if (Main.getInstance().getConfig().isSet("entity_uuid_fix") && Main.getInstance().getConfig().getBoolean("entity_uuid_fix")){
            registerNewExpression(ExprUUIDOfEntity.class, String.class, ExpressionType.SIMPLE, "entity uuid of %entity%");
        }else{
            registerNewExpression(ExprUUIDOfEntity.class, String.class, ExpressionType.SIMPLE, "[entity ]uuid of %entity%");
        }
        //endregion
        //region HOLOGRAMS (WIP)
			 /*
			  *  Holograms - Effects
	        Skript.registerEffect(EffCreateHologram.class,  "create [new] hologram at %location% with %string% in %string% [for %long%]");
	        Skript.registerEffect(EffAddLineBelow.class,  "add %string% below hologram at %location% in %string%");
	        Skript.registerEffect(EffAddLineAbove.class,  "add %string% above hologram at %location% in %string%");
	        Skript.registerEffect(EffDeleteHologram.class,  "delete hologram at %location% in %string%");
	        Skript.registerEffect(EffMoveHologram.class,  "move hologram from %location% to %location% in %string%");
	        Skript.registerEffect(EffSetText.class,  "set text of hologram at %location% to %string% in %string%");
	        Skript.registerEffect(EffSetTextAbove.class,  "set text of line above hologram at %location% to %string% in %string%");
	        Skript.registerEffect(EffSetTextBelow.class,  "set text of line below hologram at %location% to %string% in %string%");
	        Bukkit.getLogger().info("Information Gathered: Funnygatt really hates this hologram api -.-");
			 /*
			  *  Holograms - Expressions
	        registerNewExpression(ExprGetLineAbove.class, String.class, ExpressionType.SIMPLE, "text of line above hologram at %location% in %string%");
	        registerNewExpression(ExprGetLineAbove.class, String.class, ExpressionType.SIMPLE, "text of line below hologram at %location% in %string%");
	        registerNewExpression(ExprGetLineAbove.class, String.class, ExpressionType.SIMPLE, "text of hologram at %location% in %string%");
			  */
        //endregion
        //region UMBASKAAPI
        pl = Bukkit.getServer().getPluginManager().getPlugin("UmbaskaAPI");
        if (pl != null) {
            registerNewExpression(ExprFactionOfPlayer.class, String.class, ExpressionType.PROPERTY, "faction of %player%");
        }
        //endregion
        //region MISC
        registerNewExpression(ExprDelayTime.class, Integer.class, ExpressionType.PROPERTY, "delay time of %location%");
        registerNewExpression(ExprSpawnedType.class, String.class, ExpressionType.PROPERTY, "entity type of %location%");
        registerNewExpression(ExprItemName.class, String.class, ExpressionType.SIMPLE, "item name");
        registerNewExpression(EffCentredText.class, String.class, ExpressionType.SIMPLE, "cent(er|re)d %string%");
        registerNewExpression(EffCentredTextSize.class, String.class, ExpressionType.SIMPLE, "cent(er|re)d %string% [with] [max] [length] [of] %-integer%");
        registerNewExpression(ExprArmourPoints.class, Double.class, ExpressionType.PROPERTY, "(armour|armor) points of %player%");
        registerNewExpression(ExprItemCountInSlot.class, Integer.class, ExpressionType.SIMPLE, "amount of items in %itemstack%");
        registerNewExpression(ExprGetJSONString.class, String.class, ExpressionType.SIMPLE, "JSON string %string% from %string%");
        registerNewExpression(ExprGetDigits.class, String.class, ExpressionType.SIMPLE, "get (digits|numbers|nums|num) of %string%");
        registerNewExpression(ExprYAMLString.class, String.class, ExpressionType.SIMPLE, "get string %string% from %string%");
        registerNewExpression(ExprYAMLInteger.class, Integer.class, ExpressionType.SIMPLE, "get integer %string% from %string%");
        registerNewExpression(ExprYAMLBoolean.class, Boolean.class, ExpressionType.SIMPLE, "get boolean %string% from %string%");
        registerNewExpression(ExprNewLocation.class, Location.class, ExpressionType.SIMPLE, "new location %number%, %number%, %number% in world %string%");
        registerNewExpression(ExprFileExists.class, Boolean.class, ExpressionType.PROPERTY, "exist(e|a)nce of %string%");
        registerNewExpression(ExprGetFile.class, String.class, ExpressionType.PROPERTY, "file from %string%");
		registerNewExpression(ExprContent.class, String.class, ExpressionType.SIMPLE, "content[s] (from|of) file %string%");
        registerNewExpression(ExprGetLine.class, String.class, ExpressionType.SIMPLE, "line %integer% in file %string%");
        registerNewExpression(ExprFileInDir.class, String.class, ExpressionType.SIMPLE, "files in %string% (recursive|r) %boolean%");
        registerNewExpression(ExprEnchantsOfItem.class, String.class, ExpressionType.PROPERTY, "enchants of %itemstack%");
        pl = Bukkit.getServer().getPluginManager().getPlugin("NametagEdit");
        if (pl != null) {
            registerNewExpression(ExprGetPrefix.class, String.class, ExpressionType.PROPERTY, "prefix of %player%");
            registerNewExpression(ExprGetSuffix.class, String.class, ExpressionType.PROPERTY, "suffix of %player%");
            registerNewExpression(ExprGetNametag.class, String.class, ExpressionType.PROPERTY, "name tag of %player%");
        }
        //blocks in loc
        registerNewExpression(ExprLoopAllBlocks.class, Block.class, ExpressionType.SIMPLE, "[all] blocks (from|within) %location% to %location%");
        registerNewExpression(ExprLoopSolidBlocks.class, Block.class, ExpressionType.SIMPLE, "[all] solid blocks (from|within) %location% to %location%");
        registerNewExpression(ExprLoopTransparentBlocks.class, Block.class, ExpressionType.SIMPLE, "[all] (transparent|trans|t|non-solid|see through|other) blocks (from|within) %location% to %location%");
        //commandblocks
        Skript.registerExpression(ExprCommandBlockInfo.class, String.class, ExpressionType.SIMPLE, new String[]{"command of %block%", "name of %block%"});
        //endregion
        //region CLIPS PLACEHOLDERAPI
        pl = Bukkit.getServer().getPluginManager().getPlugin("PlaceholderAPI");
        if (pl != null) {
            registerNewExpression(EffParse.class, String.class, ExpressionType.PROPERTY, new String[] { "placeholder parse %string% as %player%", "placeholder parse %string%" });
            registerNewExpression(EffParse.class, String.class, ExpressionType.PROPERTY, new String[] { "placeholder parse %string% as %player%", "placeholder parse %string%" });
        }
        //endregion
        //region DYNMAP
        pl = Bukkit.getServer().getPluginManager().getPlugin("Dynmap");
        if (pl != null) {
            registerNewExpression(ExprVisOfPlayer.class, Boolean.class, ExpressionType.PROPERTY, "Dynmap visibility of %player%");
        }
        //endregion
        //region FACTIONS
        pl = Bukkit.getServer().getPluginManager().getPlugin("MassiveCore");
        if (pl != null) {
            pl = Bukkit.getServer().getPluginManager().getPlugin("Factions");
            if (pl != null) {
                SimplePropertyExpression.register(ExprNameOfFaction.class, String.class, "name", "faction");
                SimplePropertyExpression.register(ExprFactionOfPlayer.class, Faction.class, "faction", "player");
                SimplePropertyExpression.register(ExprDescriptionOfFaction.class, String.class, "description", "faction");
                SimplePropertyExpression.register(ExprPowerOfPlayer.class, Double.class, "power", "player");
                SimplePropertyExpression.register(ExprPowerboostOfPlayer.class, Double.class, "powerboost", "player");
                SimplePropertyExpression.register(ExprMOTDOfFaction.class, String.class, "motd", "faction");
                SimplePropertyExpression.register(ExprHomeOfFaction.class, Location.class, "home", "faction");
                SimplePropertyExpression.register(ExprTitleOfPlayer.class, String.class, "title", "player");
                SimplePropertyExpression.register(ExprPowerOfFaction.class, Double.class, "power", "faction");
                SimplePropertyExpression.register(ExprPowerboostOfFaction.class, Double.class, "powerboost", "faction");
                registerNewExpression(ExprFactionAtLocation.class, Faction.class, ExpressionType.SIMPLE, "[the] faction at %location%");
                registerNewExpression(ExprFactions.class, String.class, ExpressionType.SIMPLE, "list of [all] Factions", "Factions list", "all Factions");
                registerNewExpression(ExprAlliesOfFaction.class, String.class, ExpressionType.SIMPLE, "list of [all] allies of [the] [faction] %faction%", "[all] faction allies [list] of [the] [faction] %faction%");
                registerNewExpression(ExprPlayersOfFaction.class, Player.class, ExpressionType.SIMPLE, "list of [all] players of [the faction] %faction%", "[all] players['] [list] of [the faction] %faction%");
                registerNewExpression(ExprRelationshipStatus.class, Rel.class, ExpressionType.SIMPLE, "relation[ship] [status] between [the] [faction] %faction% (and|with) [the] [faction] %faction%");
                registerNewExpression(ExprRankOfPlayer.class, Rel.class, ExpressionType.SIMPLE, "role of [the] [player] %player%");
                registerNewExpression(ExprEnemiesOfFaction.class, String.class, ExpressionType.SIMPLE, "list of [all] enemies of [the] [faction] %faction%","[all] faction enemies [list] of %faction%");
                registerNewExpression(ExprTrucesOfFaction.class, String.class, ExpressionType.SIMPLE, "list of [all] truces of [the] [faction] %faction%", "[all] faction truces [list] of %faction%");
            }
        }
        //endregion
        //region MCMMO
        pl = Bukkit.getServer().getPluginManager().getPlugin("mcMMO");
        if (pl != null){
            SimplePropertyExpression.register(ExprPowerLevelOfPlayer.class, Integer.class, "power(level| level)", "player");
        }
        //endregion
        //region WILDSKRIPT
        registerNewExpression(ExprFreeMemory.class, Integer.class, ExpressionType.PROPERTY, "free memory");
        registerNewExpression(ExprJavaVersion.class, String.class, ExpressionType.PROPERTY, "java version");
        registerNewExpression(ExprMaxMemory.class, Integer.class, ExpressionType.PROPERTY, "max memory");
        registerNewExpression(ExprTotalMemory.class, Integer.class, ExpressionType.PROPERTY, "total memory");
        registerNewExpression(ExprTPS.class, Double.class, ExpressionType.PROPERTY, "tps");
        registerNewExpression(ExprPing.class, Integer.class, ExpressionType.PROPERTY, "%player%[[']s] ping");
        registerNewExpression(ExprPing.class, Integer.class, ExpressionType.PROPERTY, "ping of %player%");
        //endregion
        //region PROTOCOLLIB
        pl = Bukkit.getServer().getPluginManager().getPlugin("ProtocolLib");
        if (pl != null) {
            registerNewExpression(ExprCanSee.class, Boolean.class, ExpressionType.PROPERTY, "visibility of %entities% for %player%");
        }
        //endregion
        //region WORLDEDIT
        pl = Bukkit.getServer().getPluginManager().getPlugin("WorldEdit");
        if (pl != null){
            registerNewExpression(ExprAllSchematics.class, String.class, ExpressionType.COMBINED, "all schematics");
        }
        //endregion
        //region MISC2
        registerNewExpression(ExprDyed.class, ItemStack.class, ExpressionType.SIMPLE, "%itemstack% (colo[u]red|dyed) %color%");
        registerNewExpression(ExprDyedRGB.class, ItemStack.class, ExpressionType.SIMPLE, "%itemstack% (colo[u]red|dyed) %number%, %number%(,| and) %number%");
        registerNewExpression(ExprClickedItem.class, ItemStack.class, ExpressionType.SIMPLE, "clicked item");
        registerNewExpression(ExprClickedInventory.class, ItemStack.class, ExpressionType.SIMPLE, "clicked inventory");
        registerNewExpression(ExprCursorItem.class, ItemStack.class, ExpressionType.SIMPLE, "cursor item");
        registerNewExpression(ExprClickedSlot.class, Integer.class, ExpressionType.SIMPLE, "clicked slot");
        registerNewExpression(ExprClickType.class, String.class, ExpressionType.SIMPLE, "click type");
        registerNewExpression(ExprClickedItemName.class, String.class, ExpressionType.SIMPLE, "clicked item name");
        registerNewExpression(ExprClickedItemLore.class, String.class, ExpressionType.SIMPLE, "clicked item lore");
        //Bukkit Server Properties
        registerNewExpression(ExprMaxPlayers.class, Integer.class, ExpressionType.SIMPLE, "max players");
        //Misc1
        registerNewExpression(ExprSpawnReason.class, String.class, ExpressionType.SIMPLE, "spawn reason (of|for) %entity%");
        registerNewExpression(ExprGetScore.class, Integer.class, ExpressionType.PROPERTY, "value [of] %string% objective %string% for [score] %string%");
        //registerNewExpression(ExprGetPlayerScoreboard.class, Scoreboard.class, ExpressionType.PROPERTY, "scoreboard of %player%");
        registerNewExpression(ExprGetObjectiveType.class, String.class, ExpressionType.PROPERTY, "objective type of %string% (from|in) [score][board] %scoreboard%");
        registerNewExpression(ExprGetObjectiveDisplay.class, Objective.class, ExpressionType.PROPERTY, "objective in [[display]slot] %displayslot% from [score][board] %string%");
        registerNewExpression(ExprGetObjective.class, String.class, ExpressionType.PROPERTY, "objective %string% from [score][board] %string%");
				 /* 1.8 Things */
        //registerNewExpression(ExprBetterExplodedBlocks.class, Block.class, ExpressionType.COMBINED, "[better] exploded blocks");
        registerNewExpression(ExprDirectionLocation.class, Location.class, ExpressionType.COMBINED, "[the] (location|position) %number% (block|meter)[s] in [the] direction %direction% of %location%");
        registerNewExpression(ExprDirectionLocation.class, Location.class, ExpressionType.COMBINED, "(location|position) [of] direction %direction% (*|times|multiplied by length) %number% (from|with) [origin] %location%");
        Main.getInstance().getLogger().info("When Funnygatt and BaeFell work together, amazing things happen! \nGO! SUPER GATTFELL REGISTER SEQUENCE!\nAchievement Get! Used the new Umbaska Version");
        SimplePropertyExpression.register(ExprFreeze.class, Boolean.class, "freeze state", "player");
        SimplePropertyExpression.register(ExprCanMoveEntities.class, Boolean.class, "[can] collide [with entities]", "player");
        registerNewExpression(ExprEntityFromVariable.class, Entity.class, ExpressionType.COMBINED, "[umbaska] entity from [variable] %entity%");
        // Date
        registerNewExpression(ExprGetDate.class, Date.class, ExpressionType.SIMPLE, "date from %string% using format %string%");
        registerNewExpression(ExprGetDateWithLocale.class, Date.class, ExpressionType.SIMPLE, "date from %string% using format %string% and locale %locale%");
        registerNewExpression(ExprGetDay.class, DayOfWeek.class, ExpressionType.SIMPLE, "day[ of week] from %date%");
        registerNewExpression(ExprGetHour.class, Integer.class, ExpressionType.SIMPLE, "hour from %date%");
        registerNewExpression(ExprGetMinute.class, Integer.class, ExpressionType.SIMPLE, "minute from %date%");
        registerNewExpression(ExprGetSecond.class, Integer.class, ExpressionType.SIMPLE, "second from %date%");
        registerNewExpression(ExprGetMillisecond.class, Integer.class, ExpressionType.SIMPLE, "millisecond from %date%");
        registerNewExpression(ExprGetYear.class, Integer.class, ExpressionType.SIMPLE, "year from %date%");
        registerNewExpression(ExprFallDistance.class, Number.class, ExpressionType.SIMPLE, "fall distance of %entity%");
        SimplePropertyExpression.register(ExprForceFly.class, Boolean.class, "(is flying|force fly)", "player");
        registerNewExpression(ExprUnbreakable.class, ItemStack.class, ExpressionType.PROPERTY, "[a[n]] unbreakable %itemstacks%");

        registerNewExpression(ExprBlocksInCylinder.class, Block.class, ExpressionType.COMBINED, "blocks in cylindrical radius of %number%( [with] height|,) %number% (around|from[ block[ at]]) %location%");
        registerNewExpression(ExprEntitiesWithin.class, Entity.class, ExpressionType.COMBINED, "[all] entities (from|within|in) %location% (and|to) %location%");
        registerNewExpression(ExprOffsetLocation.class, Location.class, ExpressionType.SIMPLE, "%location% offset by %number%, %number%(,| and) %number%");
        SimplePropertyExpression.register(ExprWorldOfLocation.class, World.class, "[umbaska] world", "location");
        SimplePropertyExpression.register(ExprBlockSkullOwner.class, String.class, "[block ]skull owner", "block");
        SimplePropertyExpression.register(ExprItemStackSkullOwner.class, String.class, "[itemstack ]skull owner", "itemstack");
        SimplePropertyExpression.register(ExprItemStackSkullOwnURL.class, String.class, "skull url", "itemstack");

        registerNewExpression(ExprSkullOwnerURL.class, ItemStack.class, ExpressionType.SIMPLE, "%itemstack% [with] [skull] url %string%");
        //SimplePropertyExpression.register(ExprItemStackSkullOwnURL.class, String.class, "skull url", "itemstack");
        // Results Slot

        registerNewExpression(ExprSplashPotionEntity.class, Entity.class, ExpressionType.SIMPLE, "(thrown|splash) potion (from|using) [item] %itemstack%");
        registerNewExpression(ExprBlankEnderpearl.class, Entity.class, ExpressionType.SIMPLE, "blank %entity%");

        registerNewExpression(ExprClosestEntity.class, Entity.class, ExpressionType.SIMPLE, "closest entity from [entity] %entity%");
        SimplePropertyExpression.register(ExprGlobalKey.class, String.class, "umbaska key", "string");
        SimplePropertyExpression.register(ExprEntityBounce.class, Boolean.class, "[does] bounce", "entity");

        // Maths

        registerNewExpression(ExprArcTan.class, Number.class, ExpressionType.SIMPLE, "[umbaska] arc tan[gent] %number%");
        registerNewExpression(ExprArcSine.class, Number.class, ExpressionType.SIMPLE, "[umbaska] arc sin[e] %number%");
        registerNewExpression(ExprArcCos.class, Number.class, ExpressionType.SIMPLE, "[umbaska] arc cos[ine] %number%");
        registerNewExpression(ExprTan.class, Number.class, ExpressionType.SIMPLE, "[umbaska] tan[gent] %number%");
        registerNewExpression(ExprSine.class, Number.class, ExpressionType.SIMPLE, "[umbaska] sin[e] %number%");
        registerNewExpression(ExprCos.class, Number.class, ExpressionType.SIMPLE, "[umbaska] cos[ine] %number%");
        registerNewExpression(ExprHyperbolicTan.class, Number.class, ExpressionType.SIMPLE, "[umbaska] hyperbolic tan[gent] %number%");
        registerNewExpression(ExprHyperbolicSin.class, Number.class, ExpressionType.SIMPLE, "[umbaska] hyperbolic sin[e] %number%");
        registerNewExpression(ExprHyperbolicCos.class, Number.class, ExpressionType.SIMPLE, "[umbaska] hyperbolic cos[ine] %number%");

        registerNewExpression(ExprLogarithm.class, Number.class, ExpressionType.SIMPLE, "[umbaska] [natural ]log[arithm] %number%");
        registerNewExpression(ExprBase10.class, Number.class, ExpressionType.SIMPLE, "[umbaska] base(-| )10 [log[arithm]] %number%");
        registerNewExpression(ExprSignum.class, Number.class, ExpressionType.SIMPLE, "[umbaska] signum %number%");
        registerNewExpression(ExprSqrt.class, Number.class, ExpressionType.SIMPLE, "[umbaska] (sqrt|square root) [of] %number%");
        registerNewExpression(ExprFactorial.class, Number.class, ExpressionType.SIMPLE, "[umbaska] %number% factorial");
        registerNewExpression(ExprFactorial.class, Number.class, ExpressionType.SIMPLE, "[umbaska] %number%!");
        registerNewExpression(ExprSimpleVector.class, Vector.class, ExpressionType.SIMPLE, "[umbaska] (vector from|new vector [from]) %number%, %number%, %number%");

        //Main.getInstance().getLogger().info("GLOBAL KEY REGISTERERRRR");
        Bukkit.getLogger().info("[Umbaska] Registering Armor Stand related expressions");
        registerNewExpression(ExprClosestEntityFromLocation.class, Entity.class, ExpressionType.SIMPLE, "closest entity from [location] %location%");
        registerNewSimpleExpression("Armor Stand Marker", "ArmourStands.ExprMarker", Boolean.class, "[has] marker", "entity", true);
        registerNewSimpleExpression("NoAI", "ArmourStands.ExprNoAI", Boolean.class, "no[ ]ai[ state]", "entity", true);
        registerNewSimpleExpression("Silent", "ArmourStands.ExprSilent", Boolean.class, "silent[ state]", "entity", true);

        //(String name, String cls, Class returnType, ExpressionType expressionType, String syntax, Boolean multiversion){

        registerNewExpression("ItemAttributeGeneric", "Attributes.ExprGenericItemAttribute", ItemStack.class, ExpressionType.SIMPLE, "%itemstack% with generic [item] attribute %string% (with value of|set to|value) %number%", true);
        registerNewExpression("ItemAttributePredefined", "Attributes.ExprStatItemAttribute", ItemStack.class, ExpressionType.SIMPLE, "%itemstack% with [item] attribute %entityattribute% (with value of|set to|value) %number% (using operation|operation|with operation) %nbtoperation%", true);


        SimplePropertyExpression.register(ExprsArms.class, Boolean.class, "[show] arms", "entity");
        SimplePropertyExpression.register(ExprsBasePlate.class, Boolean.class, "[show] base plate", "entity");
        SimplePropertyExpression.register(ExprsGravity.class, Boolean.class, "[has] gravity", "entity");
        SimplePropertyExpression.register(ExprsSmall.class, Boolean.class, "[is] small", "entity");
        SimplePropertyExpression.register(ExprsVisible.class, Boolean.class, "[is] visible", "entity");
        SimplePropertyExpression.register(ExprsRightLegDirectionX.class, Number.class, "right leg (x angle|angle x)", "entity");
        SimplePropertyExpression.register(ExprsRightLegDirectionY.class, Number.class, "right leg (y angle|angle y)", "entity");
        SimplePropertyExpression.register(ExprsRightLegDirectionZ.class, Number.class, "right leg (z angle|angle z)", "entity");
        SimplePropertyExpression.register(ExprsLeftLegDirectionX.class, Number.class, "left leg (x angle|angle x)", "entity");
        SimplePropertyExpression.register(ExprsLeftLegDirectionY.class, Number.class, "left leg (y angle|angle y)", "entity");
        SimplePropertyExpression.register(ExprsLeftLegDirectionZ.class, Number.class, "left leg (z angle|angle z)", "entity");
        SimplePropertyExpression.register(ExprsRightArmDirectionX.class, Number.class, "right arm (x angle|angle x)", "entity");
        SimplePropertyExpression.register(ExprsRightArmDirectionY.class, Number.class, "right arm (y angle|angle y)", "entity");
        SimplePropertyExpression.register(ExprsRightArmDirectionZ.class, Number.class, "right arm (z angle|angle z)", "entity");
        SimplePropertyExpression.register(ExprsLeftArmDirectionX.class, Number.class, "left arm (x angle|angle x)", "entity");
        SimplePropertyExpression.register(ExprsLeftArmDirectionY.class, Number.class, "left arm (y angle|angle y)", "entity");
        SimplePropertyExpression.register(ExprsLeftArmDirectionZ.class, Number.class, "left arm (z angle|angle z)", "entity");
        SimplePropertyExpression.register(ExprsHeadDirectionX.class, Number.class, "head (x angle|angle x)", "entity");
        SimplePropertyExpression.register(ExprsHeadDirectionY.class, Number.class, "head (y angle|angle y)", "entity");
        SimplePropertyExpression.register(ExprsHeadDirectionZ.class, Number.class, "head (z angle|angle z)", "entity");
        SimplePropertyExpression.register(ExprsBodyDirectionX.class, Number.class, "body (x angle|angle x)", "entity");
        SimplePropertyExpression.register(ExprsBodyDirectionY.class, Number.class, "body (y angle|angle y)", "entity");
        SimplePropertyExpression.register(ExprsBodyDirectionZ.class, Number.class, "body (z angle|angle z)", "entity");

        SimplePropertyExpression.register(ExprZombieVillager.class, Boolean.class, "zombie villager state", "entity");

        registerNewExpression("Glow", "Misc.ExprBetterGlow", ItemStack.class, ExpressionType.SIMPLE, "[a[n]] [umbaska] glow[ing] %itemstack%", true);
        registerNewExpression("Absorption Hearts", "Misc.ExprAbsorptionHearts", Number.class, ExpressionType.SIMPLE, "absorption hearts of %player%", true);
	             /* Books! */

        registerNewExpression("No AI Entity", "Misc.ExprNoAIEntity", Entity.class, ExpressionType.PROPERTY, "%entity% with no[( |-)]ai", true);

        // 1.8

        registerNewExpression(ExprSplitAtAllCharacters.class, String.class, ExpressionType.COMBINED, "%string% split at all characters");

        //Banners
        registerNewExpression(ExprNewBannerFrom.class, ItemStack.class, ExpressionType.COMBINED, "%color% banner with layers");
        registerNewExpression(ExprNewBannerFrom.class, ItemStack.class, ExpressionType.COMBINED, "banner colo[u]red %color% with layers");
        registerNewExpression(ExprNewLayer.class, ItemStack.class, ExpressionType.COMBINED, "%itemstack% [(and|,)] colo[u]r[ed] %color% [(and|with)] pattern %bannerpattern%");

        registerNewExpression(ExprBannerLayer.class, Pattern.class, ExpressionType.SIMPLE, "[pattern] layer %integer% of %block%");
        //endregion
        //region BUNGEE
        if (use_bungee == true) {
            registerNewExpression(ExprBungeeUUID.class, UUID.class, ExpressionType.PROPERTY, "Bungee uuid of %player%");
            registerNewExpression(ExprAllServers.class, String.class, ExpressionType.SIMPLE, "all Bungee[ ][cord] servers");
            registerNewExpression(ExprBungeeAllPlayers.class, String.class, ExpressionType.SIMPLE, "all Bungee[ ][cord] players");
            registerNewExpression(ExprBungeePlayersOnServer.class, Integer.class, ExpressionType.SIMPLE, "players on Bungee[ ][cord] server %string%");
            registerNewExpression(ExprBungeeServerOfPlayer.class, String.class, ExpressionType.SIMPLE, "Bungee[ ][cord] server of %string%");
            registerNewExpression(ExprBungeeServerCount.class, Integer.class, ExpressionType.SIMPLE, "players on Bungee[ ][cord] proxy");
        }
        //endregion
        //region FAKE PACKET PLAYERS
        registerNewExpression("Get Player from Fake Player", "ProtocolLib.FakePlayer.ExprGetPlayer", Player.class, ExpressionType.SIMPLE, "player from fake player %string%", true);
        //endregion
    }
}
	

