package uk.co.umbaska.Managers;

import ch.njol.skript.ScriptLoader;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
	
	public void loadScripts(String folder) {
		File in = new File(folder);
		ScriptLoader.loadScripts(in);
	}
	
	public void createFile(String file) {
		File f = new File(file);
		if (f.exists()) {
			return;
		} else {
			try {
				f.getParentFile().mkdirs(); //Creates the directory if the directory doesn't exist, see http://docs.oracle.com/javase/7/docs/api/java/io/File.html#mkdirs%28%29 
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (SecurityException s){ //if security exception is thrown, this happens if java does not have permission to create the directory/file.
				s.printStackTrace(); //print the stack trace
			}
		}
	}
	
	public void deleteFile(String file) {
		File f = new File(file);
		if (f.exists()) {
			f.delete();
		} else {
			return;
		}
	}
	
	public String[] unrecursiveFileListing(String file) {
		List<String> files = new ArrayList<String>();
		File folder = new File(file);
		for (File fileEntry : folder.listFiles()) {
			files.add(fileEntry.getName());
		}
		if (files.size() > 0) {
	    	String[] out = new String[files.size()];
	        out = files.toArray(out);
	        return out;
	    } else {
	    	return null;
	    }
	}
	
	public String[] recursiveFileListing(String file) {
		List<String> files = new ArrayList<String>();
		File folder = new File(file);
		for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				for (String secondFile : recursiveFileListing(fileEntry.getPath())) {
					System.out.println(secondFile);
				}
			}
			files.add(fileEntry.getName());
		}
		if (files.size() > 0) {
	    	String[] out = new String[files.size()];
	        out = files.toArray(out);
	        return out;
	    } else {
	    	return null;
	    }
	}
	
	public void setLineOfFile(String file, String text, Integer l) throws IOException {
		File f = new File(file);
		
		if (!f.exists()) {
			return;
		} else if (l < 0) {
			return;
		} else { 
			l = l - 1;
	        List<String> sss = new ArrayList<String>();
			BufferedReader br = new BufferedReader(new FileReader(file));
	        try{
	            String line;
	            while ((line = br.readLine()) != null) {
	            	sss.add(line);
	            }
	        }finally {
	        	
			}
	        br.close();
			String[] out = new String[sss.size()];
	        out = sss.toArray(out);
	        out[l] = text;
	        f.delete();
	        f.createNewFile();
	        for(String write : out) {
	        	writeToFile(file, write, false);
	        }
		}
	}
		
	public String getLineOfFile(String file, Integer l) throws FileNotFoundException, IOException {
		File f = new File(file);
		
		if (!f.exists()) {
			return null;
		} else if (l < 0) {
			return null;
		} else { 
			l = l - 1;
	        List<String> sss = new ArrayList<String>();
	        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
	            String line;
	            while ((line = br.readLine()) != null) {
	            	sss.add(line);
	            }
	        }
	        String[] out = new String[sss.size()];
	        out = sss.toArray(out);
	        return out[l];
		}
	}
	
	public String[] getLinesOfFile(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		
		if (!f.exists()) {
			return null;
		} else { 
	        List<String> sss = new ArrayList<String>();
	        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
	            String line;
	            while ((line = br.readLine()) != null) {
	            	sss.add(line);
	            }
	        }
	        String[] out = new String[sss.size()];
	        out = sss.toArray(out);
	        return out;
		}
	}
			
	
	public void writeToFile(String file, String text, Boolean overwrite) {
			if (fileExists(file)) {
				Writer output = null;
				try {
					if (overwrite == true) {
						output = new BufferedWriter(new FileWriter(file, overwrite));
					} else {
						output = new BufferedWriter(new FileWriter(file));
					}
				} catch (IOException e) {
					e.printStackTrace();
				}  //clears file every time
				try {
					output.append(text + System.getProperty("line.separator"));
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return;
	}
	
	public boolean fileExists(String file) {
		File f = new File(file);
		if (f.exists()) {
			return true;
		} else {
			return false;
		}
	}
}
