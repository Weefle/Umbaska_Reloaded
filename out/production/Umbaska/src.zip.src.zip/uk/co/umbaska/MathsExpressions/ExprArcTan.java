package uk.co.umbaska.MathsExpressions;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 8/31/2015.
 */
public class ExprArcTan extends SimpleExpression<Number> {

    private Expression<Number> input;

    public Class<? extends Number> getReturnType() {

        return Number.class;
    }

    @Override
    public boolean isSingle() {
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, SkriptParser.ParseResult arg3) {
        this.input = (Expression<Number>) args[0];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "umb arctan";
    }

    @Override
    @javax.annotation.Nullable
    protected Number[] get(Event arg0) {

        return new Number[] {Math.atan(this.input.getSingle(arg0).doubleValue())};
    }
}