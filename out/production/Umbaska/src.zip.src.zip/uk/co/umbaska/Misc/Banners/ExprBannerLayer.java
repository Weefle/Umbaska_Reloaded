package uk.co.umbaska.Misc.Banners;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.block.Banner;
import org.bukkit.block.Block;
import org.bukkit.block.banner.Pattern;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 10/10/2015.
 */
public class ExprBannerLayer  extends SimpleExpression<Pattern> {

    private Expression<Block> banner;
    private Expression<Integer> layerID;

    protected Pattern[] get(Event event) {

        Banner b = (Banner)banner.getSingle(event);
        Integer l = layerID.getSingle(event);
        return new Pattern[]{b.getPattern(l)};
    }

    public boolean isSingle() {
        return true;
    }

    public Class<? extends Pattern> getReturnType() {
        return Pattern.class;
    }

    public String toString(Event event, boolean b) {
        return "Get Banner Block Layer";
    }

    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        this.banner = (Expression<Block>)expressions[1];
        this.layerID = (Expression<Integer>)expressions[0];
        return true;
    }
}
