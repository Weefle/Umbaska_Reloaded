package uk.co.umbaska.Misc.Banners;

import org.bukkit.DyeColor;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;

/**
 * Created by Zachary on 10/9/2015.
 */
public class Layer {

    public Pattern pattern;
    private PatternType patternType;
    private DyeColor dyeColor;

    public Layer(DyeColor dye, PatternType type){
        this.dyeColor = dye;
        this.patternType = type;
        this.pattern = new Pattern(dye, type);
    }

    public String serialize(){
        return "PATTERNTYPE:%PATTERNTYPE%,DYECOLOR:%DYECOLOR%".replace("%DYECOLOR%", dyeColor.getColor().toString()).replace("%PATTERNTYPE%", patternType.getIdentifier());
    }

}
