package uk.co.umbaska.Misc;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockGrowEvent;
import org.bukkit.event.world.StructureGrowEvent;

public class CropGrowEvent implements Listener {
	@EventHandler
	public void onTreeGrow(StructureGrowEvent event) {
		EvtCropGrowEvent e = new EvtCropGrowEvent(event.getBlocks().get(0));
		Bukkit.getServer().getPluginManager().callEvent(e);
		if (e.isCancelled()) {

			event.setCancelled(true);

		}
	}

	@EventHandler
	public void onCropGrow(BlockGrowEvent event) {
		EvtCropGrowEvent e = new EvtCropGrowEvent(event.getNewState());
		Bukkit.getServer().getPluginManager().callEvent(e);
		if (e.isCancelled()) {

			event.setCancelled(true);

		}
	}

}
