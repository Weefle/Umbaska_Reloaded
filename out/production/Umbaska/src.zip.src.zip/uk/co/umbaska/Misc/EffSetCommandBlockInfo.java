/*
 * EffSetCommandBlockInfo.class - Made by nfell2009
 * http://umbaska.co.uk (C) nfell2009 | 2014 - 2016
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.CommandBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;

public class EffSetCommandBlockInfo extends Effect {

    private Expression<Block> block;
    private Expression<String> input;
    int matchType;

    @Override
    protected void execute(Event event){
    	Block b = block.getSingle(event);
    	String i = input.getSingle(event);
    	if(b == null) {
    		return;
    	} else if (i == null) {
    		return;
    	}
    	CommandBlock cmb = (CommandBlock) b.getState();
        if(matchType == 0) {
        	cmb.setCommand(i);
        	cmb.update();
        } else {
        	cmb.setName(i);
        	cmb.update();
        }
    }
    
    @EventHandler
    public void onRightClick(PlayerInteractEvent e) {
        Player player = e.getPlayer();
        if (e.getClickedBlock().getType().equals(Material.WALL_SIGN) || e.getClickedBlock().getType().equals(Material.SIGN_POST)) {
            player.sendMessage("Test!");
        }
    }
    
    


    @Override
    public String toString(Event event, boolean b){
        return "set command block info";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
    	matchType = i;
        block = (Expression<Block>) expressions[0];
        input = (Expression<String>) expressions[1];
        return true;
    }
}
