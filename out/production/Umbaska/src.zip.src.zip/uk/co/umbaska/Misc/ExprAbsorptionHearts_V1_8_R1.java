package uk.co.umbaska.Misc;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.craftbukkit.v1_8_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 3/30/2015.
 */
public class ExprAbsorptionHearts_V1_8_R1 extends SimpleExpression<Number> {

    private Expression<Player> player;

    @Override
    public boolean isSingle() {
        return true;
    }

    public Class<? extends Number> getReturnType(){
        return Number.class;
    }

    @Override
    @javax.annotation.Nullable
    protected Number[] get(Event arg0) {
        return new Number[] {(((CraftPlayer) player.getSingle(arg0)).getHandle()).getAbsorptionHearts()};
    }


    @Override
    public String toString(Event event, boolean b){
        return "Absorption Hearts";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        player = (Expression<Player>) expressions[0];
        return true;
    }
}
