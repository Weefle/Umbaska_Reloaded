/*
 * ExprCommandBlockInfo.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.CommandBlock;
import org.bukkit.event.Event;

public class ExprCommandBlockInfo extends SimpleExpression<String>{

    private Expression<Block> block;
    int matchType;

    public Class<? extends String> getReturnType() {

        return String.class;
    }

    @Override
    public boolean isSingle() {
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
    	matchType = arg1;
        this.block = (Expression<Block>) args[0];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "return owner of plot";
    }

    @Override
    @javax.annotation.Nullable
    protected String[] get(Event arg0) {

    	Block b = this.block.getSingle(arg0);

        if (b == null){
            return null;
        } else if (b.getType() != Material.COMMAND) {
        	return null;
        }
        CommandBlock cmb = (CommandBlock) b.getState();
        if(matchType == 0) {
        	return new String[] { cmb.getCommand() };
        } else {
        	return new String[] { cmb.getName() };
        }
    }

}