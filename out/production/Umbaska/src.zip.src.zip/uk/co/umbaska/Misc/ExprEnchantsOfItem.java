/*
 * ExprEnchantsOfItem.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;

public class ExprEnchantsOfItem extends SimpleExpression<Enchantment>{

    private Expression<ItemStack> item;

    public Class<? extends Enchantment> getReturnType() {

        return Enchantment.class;
    }

    @Override
    public boolean isSingle() {
        return false;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
        this.item = (Expression<ItemStack>) args[0];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "enchants of item";
    }

    @Override
    @javax.annotation.Nullable
    protected Enchantment[] get(Event arg0) {

        ItemStack i = this.item.getSingle(arg0);

        if (i == null){
            return null;
        }
        //Integer l1 = -1;
        //String[] enchants = new String[i.getEnchantments().size()];
        //for (Enchantment key : i.getEnchantments().keySet()) {
        //	++l1;
        //	enchants[l1] = key.getName();
        //}
        //Integer l2 = -1;
        //for (Integer value : i.getEnchantments().values()) {
        //	++l2;
        //	enchants[l2] = enchants[l2] + " " + value;
        //}
        return i.getEnchantments().keySet().toArray(new Enchantment[i.getEnchantments().keySet().size()]);
    }

}