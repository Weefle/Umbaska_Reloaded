/*
 * ExprLoopAllBlocks.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.Event;

import java.util.ArrayList;
import java.util.List;

public class ExprLoopSolidBlocks extends SimpleExpression<Block>{

    private Expression<Location> locc1, locc2;

    public Class<? extends Block> getReturnType() {

        return Block.class;
    }

    @Override
    public boolean isSingle() {
        return false;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
        this.locc1 = (Expression<Location>) args[0];
        this.locc2 = (Expression<Location>) args[1];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "return all blocks";
    }

    @Override
    @javax.annotation.Nullable
    protected Block[] get(Event arg0) {
    	Location loc1 = this.locc1.getSingle(arg0);
    	Location loc2 = this.locc2.getSingle(arg0);

        if (loc1 == null){
            return null;
        } else if (loc2 == null) {
            return null;
        }

        List<Block> blocks = new ArrayList<Block>();
        
        int topBlockX = (loc1.getBlockX() < loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
        int bottomBlockX = (loc1.getBlockX() > loc2.getBlockX() ? loc2.getBlockX() : loc1.getBlockX());
 
        int topBlockY = (loc1.getBlockY() < loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
        int bottomBlockY = (loc1.getBlockY() > loc2.getBlockY() ? loc2.getBlockY() : loc1.getBlockY());
 
        int topBlockZ = (loc1.getBlockZ() < loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
        int bottomBlockZ = (loc1.getBlockZ() > loc2.getBlockZ() ? loc2.getBlockZ() : loc1.getBlockZ());
 
        for(int x = bottomBlockX; x <= topBlockX; x++)
        {
            for(int z = bottomBlockZ; z <= topBlockZ; z++)
            {
                for(int y = bottomBlockY; y <= topBlockY; y++)
                {
                    Block block = loc1.getWorld().getBlockAt(x, y, z);
                    Material mBlock = block.getType();
                    if(mBlock.isSolid()) {
                    	blocks.add(block);
                    }
                }
            }
        }
        Block[] out = new Block[blocks.size()];
        out = blocks.toArray(out);
        return out;
    }

}