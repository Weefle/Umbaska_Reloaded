package uk.co.umbaska.Misc;

import ch.njol.skript.expressions.base.SimplePropertyExpression;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.entity.Entity;

/**
 * Created by Zachary on 6/13/2015.
 */
public class ExprNoAIEntity_V1_8_R3 extends SimplePropertyExpression<Entity, Entity> {
    public String getPropertyName(){
        return "no ai entity";
    }

    public Entity convert(Entity ent){

		net.minecraft.server.v1_8_R3.Entity nmsent = ((CraftEntity) ent).getHandle();
		NBTTagCompound compoundTag = new NBTTagCompound();
		nmsent.c(compoundTag);
		compoundTag.setInt("NoAI", 1);
		nmsent.f(compoundTag);

        return nmsent.getBukkitEntity();
    }

    public Class<? extends Entity> getReturnType(){
        return Entity.class;
    }
}
