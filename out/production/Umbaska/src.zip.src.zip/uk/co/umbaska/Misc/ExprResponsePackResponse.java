package uk.co.umbaska.Misc;

import ch.njol.skript.ScriptLoader;
import ch.njol.skript.Skript;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.skript.log.ErrorQuality;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;

/**
 * Created by Zachary on 11/27/2015.
 */
public class ExprResponsePackResponse extends SimpleExpression<PlayerResourcePackStatusEvent.Status> {

    public Class<? extends PlayerResourcePackStatusEvent.Status> getReturnType() {

        return PlayerResourcePackStatusEvent.Status.class;
    }

    @Override
    public boolean isSingle() {
        return true;
    }

    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, SkriptParser.ParseResult arg3) {
        if(!ScriptLoader.isCurrentEvent(PlayerResourcePackStatusEvent.class)) {
            Skript.error("Cannot use resource pack status expression outside of a resource pack response event", ErrorQuality.SEMANTIC_ERROR);
            return false;
        }
        return true;
    }


    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "ParticleProjectile";
    }

    @javax.annotation.Nullable
    protected PlayerResourcePackStatusEvent.Status[] get(Event arg0) {
            return new PlayerResourcePackStatusEvent.Status[]{((PlayerResourcePackStatusEvent)arg0).getStatus()};
        }
    }

