package uk.co.umbaska.Misc.NBT;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;


/**
 * Created by Zachary on 10/25/2014.
 */
public class EffEntityNBTTagString_V1_8_R3 extends Effect {


	private Expression<Entity> entity;
	private Expression<String> nbt, value;



	@SuppressWarnings("unchecked")
	public boolean init(Expression<?>[] exprs, int i, Kleenean kleenean,
						SkriptParser.ParseResult parse) {
        this.nbt = (Expression<String>) exprs[0];
		this.entity = (Expression<Entity>) exprs[1];
		this.value = (Expression<String>) exprs[2];

		return true;
	}

	public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
		return "trail";
	}

	@Override

	protected void execute(Event event) {
		Entity[] entities = this.entity.getAll(event);
        String value = this.value.getSingle(event);
        String nbt = this.nbt.getSingle(event);
        for (Entity ent : entities) {
            net.minecraft.server.v1_8_R3.Entity nmsent = ((CraftEntity) ent).getHandle();
            NBTTagCompound compoundTag = nmsent.getNBTTag();
			compoundTag.setString(nbt, value);
            nmsent.f(compoundTag);
        }
	}
}
