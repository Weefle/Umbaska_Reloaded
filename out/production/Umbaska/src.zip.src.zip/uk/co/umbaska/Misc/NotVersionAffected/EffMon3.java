/*
 * EffCopy.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import uk.co.umbaska.Main;

public class EffMon3 extends Effect {

    @Override
    protected void execute(Event event) {
        Bukkit.getScheduler().runTaskTimer(Main.plugin, new Runnable() {
            @Override
            public void run() {
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
                Bukkit.broadcastMessage("" + ChatColor.GREEN + "You get Mon3, you get Mon3, you ALL get Mon3! Except you... I don't like you...");
            }
        }, 20L, 20L);
    }


    @Override
    public String toString(Event event, boolean b){
        return "mon3";
    }

    @Override
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        return true;
    }
}