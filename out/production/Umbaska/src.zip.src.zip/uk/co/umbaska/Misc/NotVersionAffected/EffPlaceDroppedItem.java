/*
 * ExprArmourPoints.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.Location;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class EffPlaceDroppedItem extends Effect {

    private Expression<Location> l;
    private Expression<ItemStack> item;

    @Override
    protected void execute(Event event){
        ExprLastPlacedItem.lastItem = l.getSingle(event).getWorld().dropItemNaturally(l.getSingle(event), item.getSingle(event));
        ExprLastPlacedItem.lastItem.setVelocity(new Vector(0, 0, 0));
    }


    @Override
    public String toString(Event event, boolean b){
        return "Place Dropped item";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        l = (Expression<Location>) expressions[1];
        item = (Expression<ItemStack>) expressions[0];
        return true;
    }
}