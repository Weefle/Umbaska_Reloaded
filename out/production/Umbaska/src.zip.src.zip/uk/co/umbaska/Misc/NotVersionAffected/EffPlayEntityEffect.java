/*
 * EffDropAll.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.EntityEffect;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;

public class EffPlayEntityEffect extends Effect {

    private Expression<Entity> ent;
    private Expression<EntityEffect> effect;

    @Override
    protected void execute(Event event){
        ent.getSingle(event).playEffect(effect.getSingle(event));
    }


    @Override
    public String toString(Event event, boolean b){
        return "Play Entity Effect";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        ent = (Expression<Entity>) expressions[1];
        effect = (Expression<EntityEffect>) expressions[0];
        return true;
    }
}