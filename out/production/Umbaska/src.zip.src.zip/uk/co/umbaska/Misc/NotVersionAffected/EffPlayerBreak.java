/*
 * EffNewFile.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;
import uk.co.umbaska.Enums.BukkitEffectEnum;
import uk.co.umbaska.Replacers.ParticleFunction;

@SuppressWarnings("unused")
public class EffPlayerBreak extends Effect {

    private Expression<Location> location;
    private Expression<Player> player;

    @SuppressWarnings("deprecation")
	@Override
    protected void execute(Event event) {
        Location l = location.getSingle(event);
        Player p = player.getSingle(event);
        if (l.getBlock().getType() != Material.AIR) {
            ParticleFunction.spawnEffect(BukkitEffectEnum.STEP_SOUND, new Location[]{l}, l.getBlock().getType().getId(), 0);
            Bukkit.getPluginManager().callEvent(new BlockBreakEvent(l.getBlock(), p));
            l.getBlock().breakNaturally();

        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "Force Break Blocck - Player";
    }

    @SuppressWarnings("unchecked")
	@Override
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        player = (Expression<Player>)expressions[0];
        location = (Expression<Location>)expressions[1];
        return true;
    }
}