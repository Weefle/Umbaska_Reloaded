/*
 * EffDropAll.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;

public class EffSetItemInEntity extends Effect {

    private Expression<Entity> ent;
    private Expression<ItemStack> item;

    @Override
    protected void execute(Event event){
        if (this.ent.getSingle(event).getType() == EntityType.DROPPED_ITEM) {
            Item ent = (Item) this.ent.getSingle(event);
            ent.setItemStack(item.getSingle(event));
        }else{
            return;
        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "Set Item Within Entity";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        ent = (Expression<Entity>) expressions[0];
        item = (Expression<ItemStack>) expressions[1];
        return true;
    }
}