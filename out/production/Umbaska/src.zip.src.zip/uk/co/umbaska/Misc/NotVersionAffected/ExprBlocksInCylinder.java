package uk.co.umbaska.Misc.NotVersionAffected;

/**
 * Created by Zachary on 6/7/2015.
 */

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.event.Event;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class ExprBlocksInCylinder extends SimpleExpression<Block> {
    private Expression<Location> l;
    private Expression<Number> rad;
    private Expression<Number> height;

    public Class<? extends Block> getReturnType()
    {
        return Block.class;
    }

    public boolean isSingle()
    {
        return false;
    }

    @SuppressWarnings("unchecked")
	public boolean init(Expression<?>[] expr, int matchedPattern, Kleenean kl, ParseResult pr)
    {
        rad = (Expression<Number>)expr[0];
        height = (Expression<Number>)expr[1];
        l = (Expression<Location>)expr[2];
        return true;
    }

    public String toString(@Nullable Event event, boolean b)
    {
        return "Blocks in cylinder";
    }

    @SuppressWarnings("unused")
	@Nullable
    protected Block[] get(Event event)
    {
        Integer height = this.height.getSingle(event).intValue();
        Integer r = this.rad.getSingle(event).intValue();
        Location l = this.l.getSingle(event);
        Block center = l.getBlock();
        List<Block> blks = new ArrayList<Block>();
		int cx = l.getBlockX();
		int cy = l.getBlockY();
		int cz = l.getBlockZ();
		int rSquared = r * r;
		Boolean goDown = false;
		if (height == 0){
			return null;
		}
		if (height < 0){
			goDown = true;
			height = height / -1;
		}
        for(int currentheight = 0; currentheight<height; currentheight++){ //loop through all the y values(height)
			for (int x = cx - r; x <= cx +r; x++) {
				for (int z = cz - r; z <= cz +r; z++) {
					if ((cx - x) * (cx -x) + (cz - z) * (cz - z) <= rSquared) {
						blks.add(l.getWorld().getBlockAt(x, cy, z));
					}
                }
            }
			if (!goDown) {
				cy++;
			}else{
				cy--;
			}
        }
		Block[] barry = blks.toArray(new Block[0]);
        return barry;
    }
}
