/*
 * ExprArmourPoints.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.expressions.base.SimplePropertyExpression;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;

public class ExprItemEntity extends SimplePropertyExpression<ItemStack, Entity> {
    public String getPropertyName(){
        return "entity item";
    }

    public Entity convert(ItemStack itemStack){

        Item itemEnt = (Item)Bukkit.getWorlds().get(0).dropItem(Bukkit.getWorlds().get(0).getSpawnLocation(), itemStack);
        return itemEnt;
    }

    public Class<? extends Entity> getReturnType(){
        return Entity.class;
    }
}