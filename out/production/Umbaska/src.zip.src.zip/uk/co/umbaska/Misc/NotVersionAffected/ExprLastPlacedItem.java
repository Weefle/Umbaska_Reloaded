package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 11/25/2015.
 */
public class ExprLastPlacedItem  extends SimpleExpression<Entity> {

    public static Entity lastItem;

    public Class<? extends Entity> getReturnType() {

        return Entity.class;
    }

    @Override
    public boolean isSingle() {
        return false;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, SkriptParser.ParseResult arg3) {
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "return Bungee players on server";
    }

    @Override
    @javax.annotation.Nullable
    protected Entity[] get(Event arg0) {

        if (lastItem != null) {
            return new Entity[]{lastItem};
        }else{
            return null;
        }
    }
}
