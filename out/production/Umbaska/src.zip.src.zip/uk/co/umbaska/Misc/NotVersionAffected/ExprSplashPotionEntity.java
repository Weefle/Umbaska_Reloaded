/*
 * ExprArmourPoints.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.expressions.base.SimplePropertyExpression;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.inventory.ItemStack;

public class ExprSplashPotionEntity extends SimplePropertyExpression<ItemStack, Entity> {
    public String getPropertyName(){
        return "splash potion entity";
    }

    public Entity convert(ItemStack itemStack){

        ThrownPotion thrownPotion = (ThrownPotion)Bukkit.getWorlds().get(0).spawnEntity(Bukkit.getWorlds().get(0).getSpawnLocation().subtract(0, -5000, 0), EntityType.SPLASH_POTION);
        if (itemStack.getType() == Material.POTION) {
            thrownPotion.setItem(itemStack);
        }
        thrownPotion.remove();
        return thrownPotion;
    }

    public Class<? extends Entity> getReturnType(){
        return Entity.class;
    }
}