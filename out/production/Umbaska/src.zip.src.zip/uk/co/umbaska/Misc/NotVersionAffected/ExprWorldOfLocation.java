package uk.co.umbaska.Misc.NotVersionAffected;

import ch.njol.skript.classes.Changer;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.util.coll.CollectionUtils;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 12/2/2014.
 */
public class ExprWorldOfLocation extends SimplePropertyExpression<Location, World> {
	@Override
	public World convert(Location loc) {
		if(loc == null)
			return null;
		return loc.getWorld();
	}

	@Override
	public void change(Event e, Object[] delta, Changer.ChangeMode mode) {
        Location l = getExpr().getSingle(e); //Called to get the Target which is Player in this case.
		if(l == null)
			return;
		World w = (World) (delta[0]);
		if (mode == Changer.ChangeMode.SET){
            l.setWorld(w);
		}
	}


	@SuppressWarnings("unchecked")
	@Override
	public Class<?>[] acceptChange(final Changer.ChangeMode mode) {
		if (mode == Changer.ChangeMode.SET) //SET can be replaced with REMOVE ADD or similiar stuff.
			return CollectionUtils.array(World.class); //The Class should be the TypeToGet and in this case Number.
		return null;
	}

	@Override
	public Class<? extends World> getReturnType() { //ReturnType is TypeToGet and in this case Number.
		return World.class;

	}
	@Override
	protected String getPropertyName() {
		// TODO Auto-generated method stub
		return "World of Location";
	}

}
