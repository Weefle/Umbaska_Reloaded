package uk.co.umbaska.Misc;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class TeleportCallEvent implements Listener {
	@EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
	public void onPlayerTeleport(final PlayerTeleportEvent event) {
		Player player = event.getPlayer();
		if (event.getCause() != TeleportCause.UNKNOWN) {
			EvtTeleportCallEvent e = new EvtTeleportCallEvent(player);
			Bukkit.getServer().getPluginManager().callEvent(e);
		}
	}

}
