/*
 * CondIsAlly.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.Misc.UM2_0;

import ch.njol.skript.lang.Condition;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class CondDoesntContain extends Condition {


    private Expression<Object> objectStash;
    private Expression<Object> objectToCheck;

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] expr, int i, Kleenean kl, ParseResult pr) {
        objectStash = (Expression<Object>) expr[0];
        objectToCheck = (Expression<Object>) expr[1];
        return true;
    }

    @Override
    public String toString(@Nullable Event e, boolean b) {
        return "Doesnt Contain";
    }

    @Override
    public boolean check(Event e) {
		Object[] objects = objectStash.getAll(e);
		Object[] objectsToCheck = objectToCheck.getAll(e);
		List<Object> objectList = new ArrayList<>();
		List<Object> objectList2 = new ArrayList<>();
		for (Object o : objects){
			objectList.add(o);
		}
		for (Object o : objectsToCheck){
			objectList2.add(o);
		}
		return (!Collections.disjoint(objectList, objectList2));
    }

}