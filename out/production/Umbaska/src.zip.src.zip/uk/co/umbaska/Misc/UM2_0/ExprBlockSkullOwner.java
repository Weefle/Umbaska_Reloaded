package uk.co.umbaska.Misc.UM2_0;

import ch.njol.skript.classes.Changer;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.util.coll.CollectionUtils;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Skull;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 12/2/2014.
 */
public class ExprBlockSkullOwner extends SimplePropertyExpression<Block, String> {
	@Override
	public String convert(Block ent) {
		if(ent == null)
			return null;
		return (((Skull)ent).getOwner());
	}

	@Override
	public void change(Event e, Object[] delta, Changer.ChangeMode mode) {
		Block ent = getExpr().getSingle(e); //Called to get the Target which is Player in this case.
		if(ent == null)
			return;
		if(ent.getType() != Material.SKULL){
			return;
		}
		String b = (String) (delta[0]);
		if (mode == Changer.ChangeMode.SET){
            ((Skull)ent).setOwner(b);
		}
	}


	@SuppressWarnings("unchecked")
	@Override
	public Class<?>[] acceptChange(final Changer.ChangeMode mode) {
		if (mode == Changer.ChangeMode.SET) //SET can be replaced with REMOVE ADD or similiar stuff.
			return CollectionUtils.array(String.class); //The Class should be the TypeToGet and in this case Number.
		return null;
	}

	@Override
	public Class<? extends String> getReturnType() { //ReturnType is TypeToGet and in this case Number.
		return String.class;

	}
	@Override
	protected String getPropertyName() {
		// TODO Auto-generated method stub
		return "skull owner block";
	}

}
