package uk.co.umbaska.Misc.UM2_0;

import ch.njol.skript.classes.Changer;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.util.coll.CollectionUtils;
import org.bukkit.block.Block;
import org.bukkit.block.CommandBlock;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Zombie;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 12/2/2014.
 */
public class ExprCommandBlockValue extends SimplePropertyExpression<Block, String> {
	@Override
	public String convert(Block blc) {
		if(blc == null)
			return null;
		return ((CommandBlock)blc).getCommand();
	}

	@Override
	public void change(Event e, Object[] delta, Changer.ChangeMode mode) {
		Block ent= getExpr().getSingle(e); //Called to get the Target which is Player in this case.
		if(ent == null)
			return;
		String b = (String) (delta[0]);
		((CommandBlock)ent).setCommand(b);
	}


	@SuppressWarnings("unchecked")
	@Override
	public Class<?>[] acceptChange(final Changer.ChangeMode mode) {
		if (mode == Changer.ChangeMode.SET) //SET can be replaced with REMOVE ADD or similiar stuff.
			return CollectionUtils.array(Number.class); //The Class should be the TypeToGet and in this case Number.
        if (mode == Changer.ChangeMode.ADD)
            return CollectionUtils.array(Number.class);
		if (mode == Changer.ChangeMode.REMOVE)
			return CollectionUtils.array(Number.class);
		return null;
	}

	@Override
	public Class<? extends String> getReturnType() { //ReturnType is TypeToGet and in this case Number.
		return String.class;

	}
	@Override
	protected String getPropertyName() {
		// TODO Auto-generated method stub
		return "Command Block Command";
	}

}
