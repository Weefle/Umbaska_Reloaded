package uk.co.umbaska.Misc.UM2_0;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.WitherSkull;
import org.bukkit.event.Event;

import java.util.List;

/**
 * Created by Zach on 28/07/15.
 */
public class ExprEntitiesWithin extends SimpleExpression<Entity> {

	private Expression<Location> loc1, loc2;

	@Override
	public boolean isSingle() {
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, SkriptParser.ParseResult arg3) {
		this.loc1 = (Expression<Location>) args[0];
		this.loc2 = (Expression<Location>) args[1];
		return true;
	}

	@Override
	public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
		return "entities within x and x";
	}

	@Override
	@javax.annotation.Nullable
	protected Entity[] get(Event arg0) {

		Location l1 = loc1.getSingle(arg0);
		Location l2 = loc2.getSingle(arg0);
		Location middle = null;
		if (l1.getBlockY() > l2.getBlockY()){
			middle = l1;
		}else{
			middle = l2;
		}
		Number newx, newy, newz, offsetx, offsety, offsetz;

		newx = (l1.getX()+l2.getBlockX()) / 2;
		newy = (l1.getY()+l2.getBlockY()) / 2;
		newz = (l1.getZ()+l2.getBlockZ()) / 2;
		middle.setX(newx.doubleValue());
		middle.setY(newy.doubleValue());
		middle.setZ(newz.doubleValue());

		offsetx = l1.getBlockX() - middle.getBlockX();
		offsety = l1.getBlockY() - middle.getBlockY();
		offsetz = l1.getBlockZ() - middle.getBlockZ();

		WitherSkull dummy = middle.getWorld().spawn(middle, WitherSkull.class);
		List<Entity> l = dummy.getNearbyEntities(offsetx.doubleValue(), offsety.doubleValue(), offsetz.doubleValue());
		dummy.remove();
		Entity[] ent = l.toArray(new Entity[0]);
		return ent;


	}


	public Class<? extends Entity> getReturnType(){
		return Entity.class;
	}

}
