package uk.co.umbaska.Misc.UM2_0;

import ch.njol.skript.classes.Changer;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.util.coll.CollectionUtils;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import org.apache.commons.codec.binary.Base64;
import org.bukkit.Material;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.lang.reflect.Field;
import java.util.UUID;

/**
 * Created by Zachary on 12/2/2014.
 */
public class ExprItemStackSkullOwnURL extends SimplePropertyExpression<ItemStack, String> {
	@Override

	public String convert(ItemStack ent) {
		if(ent == null)
			return null;
		return getURL(ent);
	}

	@Override
	public void change(Event e, Object[] delta, Changer.ChangeMode mode) {
		ItemStack ent = getExpr().getSingle(e); //Called to get the Target which is Player in this case.
		if(ent == null)
			return;
		if(ent.getType() != Material.SKULL_ITEM){
			return;
		}
		String b = (String) (delta[0]);
		if (mode == Changer.ChangeMode.SET){
            setURL(ent, b);
		}
	}


	@SuppressWarnings("unchecked")
	@Override
	public Class<?>[] acceptChange(final Changer.ChangeMode mode) {
		if (mode == Changer.ChangeMode.SET) //SET can be replaced with REMOVE ADD or similiar stuff.
			return CollectionUtils.array(String.class); //The Class should be the TypeToGet and in this case Number.
		return null;
	}

	@Override
	public Class<? extends String> getReturnType() { //ReturnType is TypeToGet and in this case Number.
		return String.class;

	}
	@Override
	protected String getPropertyName() {
		// TODO Auto-generated method stub
		return "skull owner url ItemStack";
	}

	public ItemStack setURL(ItemStack head, String url) {
		if(url.isEmpty())return head;
		SkullMeta headMeta = (SkullMeta) head.getItemMeta();
		GameProfile profile = new GameProfile(UUID.randomUUID(), null);
		byte[] encodedData = Base64.encodeBase64(String.format("{textures:{SKIN:{url:\"%s\"}}}", url).getBytes());
		profile.getProperties().put("textures", new Property("textures", new String(encodedData)));
		Field profileField = null;
		try {
			profileField = headMeta.getClass().getDeclaredField("profile");
			profileField.setAccessible(true);
			profileField.set(headMeta, profile);
		} catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
		head.setItemMeta(headMeta);
		return head;
	}
	public String getURL(ItemStack head) {
		SkullMeta headMeta = (SkullMeta) head.getItemMeta();
		Field profileField = null;
		String url = null;
		try {
			profileField = headMeta.getClass().getDeclaredField("profile");
			profileField.setAccessible(true);
			url = profileField.get(headMeta).toString();
			profileField.setAccessible(false);
		} catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
		return url;
	}

}
