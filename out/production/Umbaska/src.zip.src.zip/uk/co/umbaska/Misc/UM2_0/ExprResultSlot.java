package uk.co.umbaska.Misc.UM2_0;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.FurnaceInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/**
 * Created by Zach on 28/07/15.
 */
public class ExprResultSlot extends SimpleExpression<ItemStack> {

	private Expression<Player> player;

	@Override
	public boolean isSingle() {
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, SkriptParser.ParseResult arg3) {
		this.player = (Expression<Player>) args[0];
		return true;
	}

	@Override
	public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
		return "glow";
	}

	@Override
	@javax.annotation.Nullable
	protected ItemStack[] get(Event arg0) {

		ItemStack itm = new ItemStack(Material.AIR);
		Player p = this.player.getSingle(arg0);
		InventoryType t = p.getOpenInventory().getTopInventory().getType();
		Inventory i = p.getOpenInventory().getTopInventory();
		if (t == InventoryType.ANVIL){
			itm = i.getItem(2);
		}
		else if (t == InventoryType.FURNACE) {
			itm = ((FurnaceInventory) i).getResult();
		}else if (t == InventoryType.WORKBENCH){
			itm = ((CraftingInventory)i).getResult();
		}
		return new ItemStack[] {itm};
	}


	public Class<? extends ItemStack> getReturnType(){
		return ItemStack.class;
	}

}
