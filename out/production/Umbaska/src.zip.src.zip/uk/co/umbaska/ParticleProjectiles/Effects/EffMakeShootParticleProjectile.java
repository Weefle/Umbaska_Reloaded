package uk.co.umbaska.ParticleProjectiles.Effects;

import ch.njol.skript.Skript;
import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;
import org.bukkit.util.Vector;
import uk.co.umbaska.ParticleProjectiles.ParticleProjectile;
import uk.co.umbaska.ParticleProjectiles.ParticleProjectileHandler;
import uk.co.umbaska.ParticleProjectiles.UmbError;


/**
 * Created by Zachary on 9/1/2015.
 */
public class EffMakeShootParticleProjectile extends Effect {
	private Expression<Entity> shooter;
    private Expression<String> name;
    private Expression<Number> speed;

    @Override
    protected void execute(Event event){
        if (ParticleProjectileHandler.particleProjectiles.containsKey(this.name.getSingle(event))) {
			ParticleProjectile particleProjectile = ParticleProjectileHandler.particleProjectiles.get(this.name.getSingle(event));
            Vector v = getDirection(this.shooter.getSingle(event).getLocation().getYaw(), this.shooter.getSingle(event).getLocation().getPitch());
			particleProjectile.setVector(v.multiply(this.speed.getSingle(event).doubleValue()));
			try {
				particleProjectile.start();
			}catch (UmbError e){
				e.printStackTrace();
			}
        }else{
            Skript.error(Skript.SKRIPT_PREFIX + "Particle Projectile doesn't exist");
        }
    }

    public static Vector getDirection(float yaw, float pitch) {
        Vector vector = new Vector();
        double rotX = 0.017453293F * yaw;
        double rotY = 0.017453293F * pitch;
        vector.setY(-Math.sin(rotY));
        double h = Math.cos(rotY);
        vector.setX(-h * Math.sin(rotX));
        vector.setZ(h * Math.cos(rotX));
        return vector;
    }


    @Override
    public String toString(Event event, boolean b){
        return "Start Particle Projectile";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        name = (Expression<String>) expressions[1];
		shooter = (Expression<Entity>)expressions[0];
        speed = (Expression<Number>)expressions[2];
        return true;
    }
}
