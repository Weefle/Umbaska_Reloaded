package uk.co.umbaska.ParticleProjectiles.Effects;

import ch.njol.skript.Skript;
import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;
import uk.co.umbaska.Enums.ParticleEnum;
import uk.co.umbaska.ParticleProjectiles.ParticleProjectile;
import uk.co.umbaska.ParticleProjectiles.ParticleProjectileHandler;


/**
 * Created by Zachary on 9/1/2015.
 */
public class EffNewParticleProjectile extends Effect {

    private Expression<ParticleEnum> particle;
    private Expression<String> name;

    @Override
    protected void execute(Event event){
        if (!ParticleProjectileHandler.particleProjectiles.containsKey(this.name.getSingle(event))) {
            ParticleProjectile particleProjectile = new ParticleProjectile(this.particle.getSingle(event), this.name.getSingle(event));
            ParticleProjectileHandler.particleProjectiles.put(this.name.getSingle(event), particleProjectile);
        }else{
            Skript.error(Skript.SKRIPT_PREFIX + "Particle Projectile already exists with that name!");
        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "Register New Particle Projectile";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        particle = (Expression<ParticleEnum>) expressions[0];
        name = (Expression<String>) expressions[1];
        return true;
    }
}
