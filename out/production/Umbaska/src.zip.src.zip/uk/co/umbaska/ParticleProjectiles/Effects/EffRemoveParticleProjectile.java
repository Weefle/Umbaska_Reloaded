package uk.co.umbaska.ParticleProjectiles.Effects;

import ch.njol.skript.Skript;
import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;
import uk.co.umbaska.ParticleProjectiles.ParticleProjectileHandler;


/**
 * Created by Zachary on 9/1/2015.
 */
public class EffRemoveParticleProjectile extends Effect {

    private Expression<String> name;

    @Override
    protected void execute(Event event){
        if (ParticleProjectileHandler.particleProjectiles.containsKey(this.name.getSingle(event))) {
            ParticleProjectileHandler.particleProjectiles.get(this.name.getSingle(event)).stop();
            ParticleProjectileHandler.particleProjectiles.remove(this.name.getSingle(event));
        }else{
            Skript.error(Skript.SKRIPT_PREFIX + "Particle Projectile doesn't exist!");
        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "Register New Particle Projectile";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        name = (Expression<String>) expressions[0];
        return true;
    }
}
