package uk.co.umbaska.ParticleProjectiles;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.LivingEntity;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import uk.co.umbaska.Enums.ParticleEnum;
import uk.co.umbaska.Main;
import uk.co.umbaska.Replacers.ParticleFunction;

import java.util.List;

/**
 * Created by Zachary on 8/26/2015.
 */
public class ParticleProjectile {

    String name;

    ParticleEnum particleType;
    Vector vector;
    Location startLocation, currentLocation;
    Double xoff;
    Double yoff;
    Double zoff;
    Double gravity;
    Integer count = 25, particleData1 = 0, particleData2 = 0, particleSpeed = 0;
    ProjectileType type;
    Boolean running = false, paused = false, pausedInPlace = false;
    BoundingBox boundingBox;

    ParticleProjectile.ProjectileTracker projectileTracker;

    int ticksPerSecond = 20;

    public ParticleProjectile(ParticleEnum particleType, String name){
        this.particleType = particleType;
        this.running = false;
        this.name = name;
    }

    public void start() throws UmbError {
		if (this.startLocation == null) {
			throw new UmbError("Start Location not provided");
		}
		if (!isRunning()){
			this.running = true;
			boundingBox = new BoundingBox(getStartLocation(), getXoff(), getYoff());
			currentLocation = getStartLocation();
			projectileTracker = new ProjectileTracker();
			projectileTracker.run();
		}
        else{
			throw new UmbError("Already running");
		}
    }

    public void stop(){
		running = false;
        projectileTracker.task.cancel();
    }

	public void pause(){
		if (isRunning()) {
			paused = true;
            pausedInPlace = false;
		}
	}

    public void unpause(){
        if (isRunning()) {
            paused = false;
            pausedInPlace = false;
        }
    }

    public void pause(Boolean inPlace){
		if (isRunning()) {
			paused = true;
			pausedInPlace = inPlace;
		}
    }

    public int getTicksPerSecond() {
        return ticksPerSecond;
    }

	public ProjectileType getType() {
		return type;
	}

	public void setType(ProjectileType type) {
		this.type = type;
	}

	public void setTicksPerSecond(int ticksPerSecond) {
        this.ticksPerSecond = ticksPerSecond;
    }

    public void setGravity(Double gravity) {
        this.gravity = gravity;
    }

    public Double getGravity() {
        return gravity;
    }

	public void setStartLocation(Location location){
        this.startLocation = location;
    }

	public void setParticleType(ParticleEnum particleType){
        this.particleType = particleType;
    }

	public void setOffset(Double xoff, Double yoff, Double zoff){
        this.xoff = xoff;
        this.yoff = yoff;
        this.zoff = zoff;
    }

	public  void setParticleCount(Integer count){
        this.count = count;
    }

	public void setVector(Vector v){
        this.vector = v;
    }

    public boolean isRunning(){
        return this.running;
    }

    public Location getStartLocation(){
        return this.startLocation;
    }

    public ParticleEnum getParticleType(){
        return this.particleType;
    }

	public void setCurrentLocation(Location l){
		this.currentLocation = l;
	}

    public Location getCurrentLocation(){
        return this.currentLocation;
    }

    public Vector getVector(){
        return this.vector;
    }

    public Integer getCount(){
        return this.count;
    }

	public Double getXoff(){
        return this.xoff;
    }
	public Double getYoff(){
        return this.yoff;
    }
	public Double getZoff(){
        return this.zoff;
    }

    public Integer getParticleData1() {
        return particleData1;
    }

    public void setParticleData1(Integer particleData1) {
        this.particleData1 = particleData1;
    }

    public Integer getParticleData2() {
        return particleData2;
    }

    public void setParticleData2(Integer particleData2) {
        this.particleData2 = particleData2;
    }

    public Integer getParticleSpeed() {
        return particleSpeed;
    }

    public void setParticleSpeed(Integer particleSpeed) {
        this.particleSpeed = particleSpeed;
    }

	private class ProjectileTracker implements Runnable{

        List<LivingEntity> entities;
		BukkitTask task;

		public ProjectileTracker(){
			task = Bukkit.getScheduler().runTaskTimer(Main.plugin, this, getTicksPerSecond(), getTicksPerSecond());
		}

        @Override
        public void run(){
            if (isRunning()) {
                if (!paused) {
                    spawnParticles();
                    boundingBox = new BoundingBox(getStartLocation(), getXoff(), getYoff());
                    currentLocation.add(getVector());
                    if (getGravity() > 0) {
                        setVector(getVector().setY(getVector().getY() - (getGravity() / ticksPerSecond)));
                    }
                    if (currentLocation.getBlock().getType() != Material.AIR && (type == ProjectileType.STOP_ON_GROUND || type == ProjectileType.STOP_ON_BOTH)) {
						ParticleProjectileLandEvent land = new ParticleProjectileLandEvent(currentLocation, name);
                        Bukkit.getServer().getPluginManager().callEvent(land);
						if (!land.isCancelled()) {
							running = false;
							stop();
						}
                    }
                    entities = currentLocation.getWorld().getLivingEntities();
                    boolean stop = false;
                    for (LivingEntity le :entities){
                        if (le.getLocation().distanceSquared(currentLocation) < 2.2 || boundingBox.contains(le)) {
							ParticleProjectileHitEvent land = new ParticleProjectileHitEvent(le, name);
							Bukkit.getServer().getPluginManager().callEvent(land);
							if (!land.isCancelled()) {
								stop = true;
							}else{
								stop = false;
							}
                        }
                    }
                    if (type == ProjectileType.STOP_ON_HIT || type == ProjectileType.STOP_ON_BOTH){
                        if (stop) {
							running = false;
                            stop();
                        }
                    }
                    spawnParticles();
                }else{
                    if (pausedInPlace){
                        spawnParticles();
                    }
                }
            }
        }

        public void spawnParticles(){
            ParticleFunction.spawnParticle(getCount(), getParticleType(), getParticleSpeed(), getXoff(), getYoff(), getZoff(), new Location[]{getCurrentLocation()}, getParticleData1(), getParticleData2());
        }

    }


}
