package uk.co.umbaska.ParticleProjectiles;

import ch.njol.skript.Skript;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.skript.lang.ExpressionType;
import ch.njol.skript.lang.util.SimpleEvent;
import ch.njol.skript.registrations.EventValues;
import ch.njol.skript.util.Getter;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;
import uk.co.umbaska.Enums.ParticleEnum;
import uk.co.umbaska.ParticleProjectiles.Effects.*;
import uk.co.umbaska.ParticleProjectiles.Expressions.*;
import uk.co.umbaska.Utils.EnumClassInfo;

import java.util.HashMap;

/**
 * Created by Zachary on 9/1/2015.
 */
public class ParticleProjectileHandler {

    public static HashMap<String, ParticleProjectile> particleProjectiles = new HashMap<>();

    public ParticleProjectileHandler(){

        // Events

		EnumClassInfo.create(ProjectileType.class, "particleprojectiletype").register();

        Skript.registerEvent("Particle Hit", SimpleEvent.class, ParticleProjectileHitEvent.class, new String[]{"particle projectile hit [event]"});
        EventValues.registerEventValue(ParticleProjectileHitEvent.class, Entity.class, new Getter<Entity, ParticleProjectileHitEvent>() {
            public Entity get(ParticleProjectileHitEvent event) {
                return event.getVictim();
            }
        }, 0);

        EventValues.registerEventValue(ParticleProjectileHitEvent.class, String.class, new Getter<String, ParticleProjectileHitEvent>() {
            public String get(ParticleProjectileHitEvent event) {
                return event.getParticleName();
            }
        }, 0);

        Skript.registerEvent("Particle Land", SimpleEvent.class, ParticleProjectileLandEvent.class, new String[]{"particle projectile land [event]"});
        EventValues.registerEventValue(ParticleProjectileLandEvent.class, Location.class, new Getter<Location, ParticleProjectileLandEvent>() {
            public Location get(ParticleProjectileLandEvent event) {
                return event.getLocation();
            }
        }, 0);
        EventValues.registerEventValue(ParticleProjectileLandEvent.class, String.class, new Getter<String, ParticleProjectileLandEvent>() {
            public String get(ParticleProjectileLandEvent event) {
                return event.getParticleName();
            }
        }, 0);

        // Effects

        Skript.registerEffect(EffNewParticleProjectile.class, "(create|register) [new] particle projectile (using|of) %particleenum%[ and][ id] %string%");
        Skript.registerEffect(EffRemoveParticleProjectile.class, "(delete|un[-]register) particle projectile %string%");
		Skript.registerEffect(EffPauseInPlaceParticleProjectile.class, "pause [in place ]particle projectile %string%[ in place]");
		Skript.registerEffect(EffPauseParticleProjectile.class, "pause particle projectile %string%");
        Skript.registerEffect(EffUnpauseParticleProjectile.class, "unpause particle projectile %string%");
		Skript.registerEffect(EffStartParticleProjectile.class, "(start|run) particle projectile %string%");
		Skript.registerEffect(EffStopParticleProjectile.class, "stop particle projectile %string%");
		Skript.registerEffect(EffMakeShootParticleProjectile.class, "(force|make) %entity% shoot particle projectile %string% with speed %number%");

		// Expressions

		SimplePropertyExpression.register(ExprStartLocation.class, Location.class, "[particle projectile] start location", "string");
		SimplePropertyExpression.register(ExprCurrentLocation.class, Location.class, "[particle projectile] current location", "string");
		SimplePropertyExpression.register(ExprGravity.class, Number.class, "[particle projectile] gravity", "string");
		SimplePropertyExpression.register(ExprParticleCount.class, Number.class, "[particle projectile] particle count", "string");
		SimplePropertyExpression.register(ExprParticleData1.class, Number.class, "[particle projectile] particle data 1", "string");
		SimplePropertyExpression.register(ExprParticleData2.class, Number.class, "[particle projectile] particle data 2", "string");
		SimplePropertyExpression.register(ExprParticleSpeed.class, Number.class, "[particle projectile] particle speed", "string");
		SimplePropertyExpression.register(ExprParticleType.class, ParticleEnum.class, "[particle projectile] particle type", "string");
		SimplePropertyExpression.register(ExprProjectileVector.class, Vector.class, "[particle projectile] (vector|velocity)", "string");
		SimplePropertyExpression.register(ExprTicksPerSecond.class, Number.class, "[particle projectile] (ticks per second|tps)", "string");
		SimplePropertyExpression.register(ExprXOffset.class, Number.class, "[particle projectile] x offset", "string");
		SimplePropertyExpression.register(ExprYOffset.class, Number.class, "[particle projectile] y offset", "string");
		SimplePropertyExpression.register(ExprZOffset.class, Number.class, "[particle projectile] z offset", "string");

		SimplePropertyExpression.register(ExprProjectileType.class, ProjectileType.class, "[particle projectile] projectile type", "string");

		Skript.registerExpression(ExprCurrentParticleProjectile.class, String.class, ExpressionType.SIMPLE, "([event-]particle projectile|name of [event-]particle projectile)");
        Skript.registerExpression(ExprAllParticleProjectiles.class, String.class, ExpressionType.COMBINED, "all particle projectiles");
        Skript.registerExpression(ExprHasStopped.class, Boolean.class, ExpressionType.SIMPLE, "running state of [particle projectile] %string%");

    }

}
