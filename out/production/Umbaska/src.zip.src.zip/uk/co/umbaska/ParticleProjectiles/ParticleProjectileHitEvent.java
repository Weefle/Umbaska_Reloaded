package uk.co.umbaska.ParticleProjectiles;

import org.bukkit.entity.Entity;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Created by Zachary on 9/1/2015.
 */
public class ParticleProjectileHitEvent extends Event implements Cancellable{

    private String particleName;
    private Entity victim;
    private boolean isCancelled;
    private static final HandlerList handlers = new HandlerList();

    public ParticleProjectileHitEvent(Entity victim, String particleName){
        this.victim = victim;
        this.particleName = particleName;
        this.isCancelled = false;
    }

    public Entity getVictim() {
        return victim;
    }

    public String getParticleName() {
        return particleName;
    }


    @Override
    public boolean isCancelled() {
        return this.isCancelled;
    }

    @Override
    public void setCancelled(boolean arg0) {
        this.isCancelled = arg0;
    }

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

}
