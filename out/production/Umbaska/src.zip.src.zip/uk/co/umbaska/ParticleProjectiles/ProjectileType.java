package uk.co.umbaska.ParticleProjectiles;

/**
 * Created by Zachary on 8/26/2015.
 */
public enum ProjectileType{
    STOP_ON_HIT,
    STOP_ON_GROUND,
    STOP_ON_BOTH,
    NEVER_STOP;
}