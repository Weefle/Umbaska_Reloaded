package uk.co.umbaska.ParticleProjectiles;

@SuppressWarnings("serial")
public class UmbError extends Exception{

    public UmbError( String s ) {
        super(s);
    }

}