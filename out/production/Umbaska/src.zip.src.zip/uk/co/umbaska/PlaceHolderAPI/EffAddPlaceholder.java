/*
 * EffAddPlaceholder.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2016
 * Submitted to: Umbaska
 * 
 */


package uk.co.umbaska.PlaceHolderAPI;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;

import org.bukkit.event.Event;

import uk.co.umbaska.Managers.Register;

public class EffAddPlaceholder extends Effect {

    private Expression<String> variable, value, plugin;
    
    @Override
    protected void execute(Event event){
        String var = variable.getSingle(event);
        String val = value.getSingle(event);
        if(plugin != null) {
        	String pl = plugin.getSingle(event);
        	var = pl + "_" + var;
        }
        if(Register.placeholderMap.containsKey(var)) {
        	Register.placeholderMap.remove(var);
        	Register.placeholderMap.put(var, val);
        } else {
        	Register.placeholderMap.put(var, val);
        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "add variable {nfell2009_says_hi_to_you} with value %string% to placeholders";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        variable = (Expression<String>) expressions[0];
        value = (Expression<String>) expressions[1];
        if(i == 1) {
        	plugin = (Expression<String>) expressions[2]; 
        }
        return true;
    }
}