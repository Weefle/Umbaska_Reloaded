/*
 * EffAddPlugin.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2016
 * Submitted to: Umbaska
 * 
 */


package uk.co.umbaska.PlaceHolderAPI;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.PlaceholderHook;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;

import uk.co.umbaska.Managers.Register;

public class EffAddPlugin extends Effect {

    private Expression<String> variable;
    
    @Override
    protected void execute(Event event){
        final String var = variable.getSingle(event);
        PlaceholderAPI.registerPlaceholderHook(var, new PlaceholderHook() {
			@Override
            public String onPlaceholderRequest(Player p, String identifier) {
                if (Register.placeholderMap.containsKey(var + "_" + identifier)) {
                    return (String) Register.placeholderMap.get(var + "_" + identifier);
                }
                return null;
            }
        });
    }


    @Override
    public String toString(Event event, boolean b){
        return "add variable {nfell2009_says_hi_to_you} with value %string% to placeholders";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        variable = (Expression<String>) expressions[0];
        return true;
    }
}