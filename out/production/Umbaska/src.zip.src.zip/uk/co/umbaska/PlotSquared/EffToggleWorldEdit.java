/*
 * EffClearPlot.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.PlotSquared;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;

import com.intellectualcrafters.plot.object.PlotPlayer;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class EffToggleWorldEdit extends Effect {

    private Expression<Player> player;
    private Expression<Boolean> setting;
    private Integer matchType;

    @Override
    protected void execute(Event event){
        Player pl = player.getSingle(event);
        if (pl == null) {
            return;
        }
        PlotPlayer pp = PlotPlayer.get(player.toString());
        if(matchType == 0 || matchType == 3 || matchType == 4) {
        	Boolean s = null;
        	if(matchType == 0) {
        		s = setting.getSingle(event);
        	} else if(matchType == 3) {
        		s = true;
        	} else {
        		s = false;
        	}
	        if (s == null) {
	        	return;
	        }
	        if(pp == null) {
	        	return;
	        }
	        if(s == true) {
	        	if (!pp.getAttribute("worldedit")) {
	        		pp.setAttribute("worldedit");
	        	}
	        } else {
	        	if (pp.getAttribute("worldedit")) {
	        		pp.removeAttribute("worldedit");
	        	}
	        }
        } else {
        	if (pp.getAttribute("worldedit")) {
	         	pp.removeAttribute("worldedit");
	        } else {
	        	pp.setAttribute("worldedit");
	        }  
        }
        
             
    }

    @Override
    public String toString(Event event, boolean b){
        return "set worldedit of %player% to true OR toggle worldedit of player";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
    	player = (Expression<Player>) expressions[0];
    	if(i == 0) {
    		setting = (Expression<Boolean>) expressions[1];
    	}
    	matchType = i;
        return true;
    }

}