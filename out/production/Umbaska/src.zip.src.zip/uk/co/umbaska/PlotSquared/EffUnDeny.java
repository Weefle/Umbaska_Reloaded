/*
 * EffUnDeny.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.PlotSquared;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import com.intellectualcrafters.plot.object.Plot;
import com.intellectualcrafters.plot.object.PlotId;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class EffUnDeny extends Effect {

    private Expression<String> plot;
    private Expression<Player> player;

    @Override
    protected void execute(Event event){
        String pl = plot.getSingle(event);
        Player p = player.getSingle(event);
        if (pl == null) {
            return;
        } else if (p == null) {
            return;
        }
        PlotId plotid = PlotId.fromString(pl);
        Plot plot = Plot.getPlot(p.getWorld().toString(), plotid);
        plot.addDenied(p.getUniqueId());
        
    }


    @Override
    public String toString(Event event, boolean b){
        return "Allow a player to a plot";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        plot = (Expression<String>) expressions[0];
        player = (Expression<Player>) expressions[1];
        return true;
    }
}