/*
 * ExprGetOwner.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.PlotSquared;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import com.intellectualcrafters.plot.object.Plot;
import com.intellectualcrafters.plot.object.PlotId;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.event.Event;

import java.util.ArrayList;
import java.util.UUID;

public class ExprGetOwner extends SimpleExpression<String>{

    private Expression<String> plot;
    private Expression<World> world;

    public Class<? extends String> getReturnType() {

        return String.class;
    }

    @Override
    public boolean isSingle() {
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
        this.plot = (Expression<String>) args[0];
        this.world = (Expression<World>) args[1];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "return owner of plot";
    }

    @Override
    @javax.annotation.Nullable
    protected String[] get(Event arg0) {

        String pl = this.plot.getSingle(arg0);
        World w = this.world.getSingle(arg0);

        if (pl == null){
            return null;
        } else if (w == null) {
        	return null;
        }

        PlotId plotid = PlotId.fromString(pl);
        Plot plot = Plot.getPlot(w.toString(), plotid);
        ArrayList<String> ownedPlots = new ArrayList<String>();
        for (UUID owner : plot.getOwners()) {
    		ownedPlots.add(Bukkit.getServer().getPlayer(owner).toString());
    	}
        String[] out = new String[ownedPlots.size()];
        out = ownedPlots.toArray(out);

        return out;
    }

}