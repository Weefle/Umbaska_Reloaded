/*
 * ExprGetPlayerPlots.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.PlotSquared;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import com.intellectualcrafters.plot.PS;
import com.intellectualcrafters.plot.object.Plot;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

import java.util.ArrayList;
import java.util.UUID;

public class ExprGetPlayerPlots extends SimpleExpression<String>{

    private Expression<Player> player;


    public Class<? extends String> getReturnType() {

        return String.class;
    }

    @Override
    public boolean isSingle() {
        return false;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
        this.player = (Expression<Player>) args[0];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "return owner of plot";
    }

    @Override
    @javax.annotation.Nullable
    protected String[] get(Event arg0) {

        Player p = this.player.getSingle(arg0);

        if (p == null){
            return null;
        }        
        ArrayList<String> ownedPlots = new ArrayList<String>();
        for (Plot plot : PS.get().getPlots()) {
        	for (UUID owner : plot.getOwners()) {
        		if (owner.equals(p.getUniqueId())) {
        			ownedPlots.add(plot.getId().toString());
        		}
        	}
        }
        String[] out = new String[ownedPlots.size()];
        out = ownedPlots.toArray(out);

        return out;
    }

}