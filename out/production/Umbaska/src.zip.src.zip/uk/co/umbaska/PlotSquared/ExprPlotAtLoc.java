/*
 * ExprPlotAtLoc.class - Made by nfell2009
 * nfell2009.uk (C) nfell2009 | 2014 - 2015
 * Submitted to: Umbaska
 * 
*/

package uk.co.umbaska.PlotSquared;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import com.intellectualcrafters.plot.object.Plot;
import org.bukkit.Location;
import org.bukkit.event.Event;



public class ExprPlotAtLoc extends SimpleExpression<String>{

    private Expression<Location> location;

    public Class<? extends String> getReturnType() {

        return String.class;
    }

    @Override
    public boolean isSingle() {
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean init(Expression<?>[] args, int arg1, Kleenean arg2, ParseResult arg3) {
        this.location = (Expression<Location>) args[0];
        return true;
    }

    @Override
    public String toString(@javax.annotation.Nullable Event arg0, boolean arg1) {
        return "return plot id at location";
    }

    @Override
    @javax.annotation.Nullable
    protected String[] get(Event arg0) {

        Location location = this.location.getSingle(arg0);

        if (location == null){
            return null;
        }
        com.intellectualcrafters.plot.object.Location loc = new com.intellectualcrafters.plot.object.Location();
        loc.setWorld(location.getWorld().toString());
        loc.setX((int) location.getX());
        loc.setY((int) location.getY());
        loc.setZ((int) location.getZ());
        loc.setPitch(location.getPitch());
        loc.setYaw(location.getYaw());
        String plot = Plot.getPlot(loc).getId().toString();

        return new String[] { plot };
    }

}