package uk.co.umbaska.ProtocolLib.Disguises;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.Event;
import uk.co.umbaska.Main;
import uk.co.umbaska.Utils.Disguise.DisguiseAPI_V1_8_R1;
import uk.co.umbaska.Utils.Disguise.DisguiseUTIL.EntityDisguise_V1_8_R1;
import uk.co.umbaska.Utils.Disguise.EntityDisguise;

/**
 * Created by Zachary on 5/6/2015.
 */
public class EffDisguiseAsEntity_V1_8_R1 extends Effect {

    private Expression<EntityDisguise> enttype;
    private Expression<Entity> entity;

    @Override
    protected void execute(Event event){
        Entity[] p = entity.getAll(event);
        EntityType e = enttype.getSingle(event).getEntityType();
        if (p == null || e == null) {
            return;
        }
        for (Entity p1 : p){
            EntityDisguise_V1_8_R1 entDisguise = new EntityDisguise_V1_8_R1(p1, e);
            ((DisguiseAPI_V1_8_R1) Main.disguiseAPI).disguisePlayer(p1, entDisguise, ((DisguiseAPI_V1_8_R1) Main.disguiseAPI).online());
        }

    }


    @Override
    public String toString(Event event, boolean b){
        return "Hide Entity";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        enttype = (Expression<EntityDisguise>) expressions[1];
        entity = (Expression<Entity>) expressions[0];
        return true;
    }
}
