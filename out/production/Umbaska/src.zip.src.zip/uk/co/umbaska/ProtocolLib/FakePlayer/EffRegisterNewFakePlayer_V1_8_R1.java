package uk.co.umbaska.ProtocolLib.FakePlayer;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;
import uk.co.umbaska.ProtocolLib.FakePlayerTracker_R1;

/**
 * Created by Zachary on 11/8/2015.
 */
public class EffRegisterNewFakePlayer_V1_8_R1 extends Effect {

    private Expression<String> name;

    @Override
    protected void execute(Event event) {
        String p = name.getSingle(event);
        if (p == null) {
            return;
        }
        FakePlayerTracker_R1.registerNewPlayer(p);

    }


    @Override
    public String toString(Event event, boolean b) {
        return "Register new Fake Player";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        name = (Expression<String>) expressions[0];
        return true;
    }
}