package uk.co.umbaska.ProtocolLib.FakePlayer;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.Location;
import org.bukkit.event.Event;
import uk.co.umbaska.ProtocolLib.FakePlayerTracker_R3;

/**
 * Created by Zachary on 11/8/2015.
 */
public class EffSetLocation_V1_8_R3 extends Effect {

    private Expression<String> name;
    private Expression<Location> loc;

    @Override
    protected void execute(Event event) {
        String p = name.getSingle(event);
        if (p == null) {
            return;
        }
        FakePlayerTracker_R3.teleport(p, loc.getSingle(event));
    }


    @Override
    public String toString(Event event, boolean b) {
        return "Set User Skin";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        name = (Expression<String>) expressions[0];
        loc = (Expression<Location>) expressions[1];
        return true;
    }
}