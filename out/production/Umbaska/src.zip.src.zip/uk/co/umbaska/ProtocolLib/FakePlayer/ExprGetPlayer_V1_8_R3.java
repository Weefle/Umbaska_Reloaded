package uk.co.umbaska.ProtocolLib.FakePlayer;

import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import uk.co.umbaska.ProtocolLib.FakePlayerTracker_R3;

/**
 * Created by Zachary on 3/30/2015.
 */
public class ExprGetPlayer_V1_8_R3 extends SimpleExpression<Player> {

    private Expression<String> player;

    @Override
    public boolean isSingle() {
        return true;
    }

    public Class<? extends Player> getReturnType(){
        return Player.class;
    }

    @Override
    @javax.annotation.Nullable
    protected Player[] get(Event arg0) {
        if (FakePlayerTracker_R3.getPlayer(player.getSingle(arg0)) != null) {
            return new Player[]{FakePlayerTracker_R3.getPlayer(player.getSingle(arg0)).getBukkitEntity().getPlayer()};
        }else{
            return null;
        }
    }


    @Override
    public String toString(Event event, boolean b){
        return "Get player from fake player";
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult){
        player = (Expression<String>) expressions[0];
        return true;
    }
}
