package uk.co.umbaska.ProtocolLib.FakePlayer;

import ch.njol.skript.classes.Changer;
import ch.njol.skript.expressions.base.SimplePropertyExpression;
import ch.njol.util.coll.CollectionUtils;
import org.bukkit.event.Event;
import uk.co.umbaska.ProtocolLib.FakePlayerTracker_R3;

/**
 * Created by Zachary on 12/2/2014.
 */
public class ExprSneaking_V1_8_R3 extends SimplePropertyExpression<String, Boolean> {
	@Override
	public Boolean convert(String id) {
		if(id == null)
			return null;
		return FakePlayerTracker_R3.isSneaking(id);
	}

	@Override
	public void change(Event e, Object[] delta, Changer.ChangeMode mode) {
		String id = getExpr().getSingle(e); //Called to get the Target which is Player in this case.
		if(id == null)
			return;
		boolean b = (Boolean) (delta[0]);
		if (mode == Changer.ChangeMode.SET){
			FakePlayerTracker_R3.sneak(id, b);
		}
	}


	@SuppressWarnings("unchecked")
	@Override
	public Class<?>[] acceptChange(final Changer.ChangeMode mode) {
		if (mode == Changer.ChangeMode.SET) //SET can be replaced with REMOVE ADD or similiar stuff.
			return CollectionUtils.array(Boolean.class); //The Class should be the TypeToGet and in this case Number.
		return null;
	}

	@Override
	public Class<? extends Boolean> getReturnType() { //ReturnType is TypeToGet and in this case Number.
		return Boolean.class;

	}
	@Override
	protected String getPropertyName() {
		// TODO Auto-generated method stub
		return "Fake Player is Sneaking";
	}

}
