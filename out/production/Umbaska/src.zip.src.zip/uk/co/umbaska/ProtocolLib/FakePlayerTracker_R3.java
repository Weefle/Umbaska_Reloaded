package uk.co.umbaska.ProtocolLib;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.v1_8_R3.*;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import uk.co.umbaska.Utils.Disguise.DisguiseUTIL.UUIDRetriever;

import java.util.HashMap;
import java.util.UUID;

/**
 * Created by Zachary on 11/8/2015.
 */
public class FakePlayerTracker_R3 {

    public static HashMap<String, EntityPlayer> playertracker = new HashMap<>();
    public static HashMap<String, String> displaynameholder = new HashMap<>();
    public static HashMap<String, String> skinholder = new HashMap<>();

    public static Boolean registerNewPlayer(String id){
        if (playertracker.containsKey(id)){
            return false;
        }else{
            UUID uid = new UUIDRetriever(id).getUUID();
            GameProfile gp = new GameProfile(uid == null ? UUID.randomUUID() : uid, id);
            UUIDRetriever.setSkin(gp);
            EntityPlayer newPlayer = new EntityPlayer(MinecraftServer.getServer(), (WorldServer)MinecraftServer.getServer().getWorld(), gp, new PlayerInteractManager(MinecraftServer.getServer().getWorld()));
            playertracker.put(id, newPlayer);
            displaynameholder.put(id, id);
            skinholder.put(id, id);
            start(id);
            return true;
        }
    }

    public static EntityPlayer getPlayer(String id){
        if (playertracker.containsKey(id)) {
            return playertracker.get(id);
        }else{
            return null;
        }
    }

    public static String getDisName(String id){
        if (displaynameholder.containsKey(id)) {
            return displaynameholder.get(id);
        }else{
            return null;
        }
    }

    public static String getSkin(String id){
        if (skinholder.containsKey(id)) {
            return skinholder.get(id);
        }else{
            return null;
        }
    }

    public static void setDisplayName(String id, String value){
        EntityPlayer p = getPlayer(id);
        if (p != null){
            UUID uid = new UUIDRetriever(getSkin(id)).getUUID();
            GameProfile gp = new GameProfile(uid == null ? UUID.randomUUID() : uid, value);
            UUIDRetriever.setSkin(gp);
            EntityPlayer newPlayer = new EntityPlayer(MinecraftServer.getServer(), (WorldServer)MinecraftServer.getServer().getWorld(), gp, new PlayerInteractManager(MinecraftServer.getServer().getWorld()));
            newPlayer.setLocation(p.locX, p.locY, p.locZ, p.pitch, p.yaw);
            newPlayer.world = p.getWorld();
            newPlayer.inventory = p.inventory;
            newPlayer.displayName = p.displayName;
            newPlayer.setHealth(p.getHealth());
            playertracker.remove(id);
            playertracker.put(id, newPlayer);
            displaynameholder.put(id, value);
            refresh(p, newPlayer);
        }
    }

    public static void setSkin(String id, String value){
        EntityPlayer p = getPlayer(id);
        if (p != null){
            UUID uid = new UUIDRetriever(value).getUUID();
            GameProfile gp = new GameProfile(uid == null ? UUID.randomUUID() : uid, getDisName(id));
            UUIDRetriever.setSkin(gp);
            EntityPlayer newPlayer = new EntityPlayer(MinecraftServer.getServer(), (WorldServer)MinecraftServer.getServer().getWorld(), gp, new PlayerInteractManager(MinecraftServer.getServer().getWorld()));
            newPlayer.setLocation(p.locX, p.locY, p.locZ, p.pitch, p.yaw);
            newPlayer.world = p.getWorld();
            newPlayer.inventory = p.inventory;
            newPlayer.displayName = p.displayName;
            newPlayer.setHealth(p.getHealth());
            playertracker.remove(id);
            playertracker.put(id, newPlayer);
            skinholder.put(id, value);
            refresh(p, newPlayer);
        }
    }

    public static Boolean isSneaking(String id){
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            return ep.isSneaking();
        }else{
            return false;
        }
    }

    public static void sneak(String id, boolean sneak) {
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            ep.setSneaking(sneak);
            PacketPlayOutEntityMetadata meta = new PacketPlayOutEntityMetadata(
                    ep.getId(), ep.getDataWatcher(), true);
            for (Player p : Bukkit.getServer().getOnlinePlayers()) {
                EntityPlayer aep = ((CraftPlayer) p).getHandle();
                aep.playerConnection.sendPacket(meta);
            }
        }
    }

    public static void swingArm(String id) {
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            PacketPlayOutAnimation animation = new PacketPlayOutAnimation(ep, 0);
            for (Player p : Bukkit.getServer().getOnlinePlayers()) {
                EntityPlayer aep = ((CraftPlayer) p).getHandle();
                aep.playerConnection.sendPacket(animation);
            }
        }
    }

    public static void setItemInHand(String id, int slot) {
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            PacketPlayOutHeldItemSlot held = new PacketPlayOutHeldItemSlot(slot);
            for (Player p : Bukkit.getServer().getOnlinePlayers()) {
                EntityPlayer aep = ((CraftPlayer) p).getHandle();
                aep.playerConnection.sendPacket(held);
            }
        }
    }

    public static void move(String id, Location newloc) {
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            Location loc = new Location(ep.getWorld().getWorld(), ep.locX, ep.locY, ep.locX);
            move(id, loc, newloc);
        }
    }

    public static void move(String id, Location old, Location newloc) {
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            PacketPlayOutEntity.PacketPlayOutRelEntityMoveLook moveLook = new PacketPlayOutEntity.PacketPlayOutRelEntityMoveLook(
                    ep.getId(),
                    (byte) ((newloc.getBlockX() - old.getBlockX()) * 32),
                    (byte) ((newloc.getBlockY() - old.getBlockY()) * 32),
                    (byte) ((newloc.getBlockZ() - old.getBlockZ()) * 32), (byte) 0,
                    (byte) 0, ep.getBukkitEntity().isOnGround());
            PacketPlayOutEntity.PacketPlayOutEntityLook look = new PacketPlayOutEntity.PacketPlayOutEntityLook(
                    ep.getId(), (byte) (newloc.getYaw() * 256 / 360),
                    (byte) (newloc.getPitch() * 256 / 360),
                    ep.getBukkitEntity().isOnGround());
            PacketPlayOutEntityHeadRotation rotation = new PacketPlayOutEntityHeadRotation(
                    ep, (byte) (newloc.getYaw() * 256 / 360));
            ep.yaw = newloc.getYaw();
            ep.pitch = newloc.getPitch();
            for (Player p : Bukkit.getServer().getOnlinePlayers()) {
                EntityPlayer aep = ((CraftPlayer) p).getHandle();
                aep.playerConnection.sendPacket(moveLook);
                aep.playerConnection.sendPacket(look);
                aep.playerConnection.sendPacket(rotation);
            }
        }
    }

    public static void teleport(String id, Location newloc){
        EntityPlayer ep = getPlayer(id);
        if (ep != null) {
            ep.setLocation(newloc.getX(), newloc.getY(), newloc.getZ(), newloc.getPitch(), newloc.getYaw());
            ep.world = (World)newloc.getWorld();
            PacketPlayOutEntityTeleport teleport = new PacketPlayOutEntityTeleport(ep.getId(), (int)newloc.getX()*32, (int)newloc.getY()*32, (int)newloc.getZ()*32, (byte)newloc.getYaw(), (byte)newloc.getPitch(), ep.onGround);
            ep.yaw = newloc.getYaw();
            ep.pitch = newloc.getPitch();
            for (Player p : Bukkit.getServer().getOnlinePlayers()) {
                EntityPlayer aep = ((CraftPlayer) p).getHandle();
                aep.playerConnection.sendPacket(teleport);
            }
        }
    }

    public static void refresh(EntityPlayer old, EntityPlayer newp){
        PacketPlayOutEntityDestroy destroy = new PacketPlayOutEntityDestroy(
                old.getId());
        PacketPlayOutPlayerInfo infoRemove = new PacketPlayOutPlayerInfo(
                PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, old);
        PacketPlayOutPlayerInfo infoAdd = new PacketPlayOutPlayerInfo(
                PacketPlayOutPlayerInfo.EnumPlayerInfoAction.ADD_PLAYER, newp);
        PacketPlayOutNamedEntitySpawn spawn = new PacketPlayOutNamedEntitySpawn(
                newp);
        for (Player p : Bukkit.getServer().getOnlinePlayers()) {
            EntityPlayer aep = ((CraftPlayer) p).getHandle();
            PlayerConnection pc = aep.playerConnection;
            pc.sendPacket(destroy);
            pc.sendPacket(infoRemove);
            pc.sendPacket(infoAdd);
            pc.sendPacket(spawn);
        }
    }

    public static void start(String id){
        PacketPlayOutPlayerInfo infoAdd = new PacketPlayOutPlayerInfo(
                PacketPlayOutPlayerInfo.EnumPlayerInfoAction.ADD_PLAYER, getPlayer(id));
        PacketPlayOutNamedEntitySpawn spawn = new PacketPlayOutNamedEntitySpawn(
                getPlayer(id));
        for (Player p : Bukkit.getServer().getOnlinePlayers()) {
            EntityPlayer aep = ((CraftPlayer) p).getHandle();
            PlayerConnection pc = aep.playerConnection;
            pc.sendPacket(infoAdd);
            pc.sendPacket(spawn);
        }
    }

}
