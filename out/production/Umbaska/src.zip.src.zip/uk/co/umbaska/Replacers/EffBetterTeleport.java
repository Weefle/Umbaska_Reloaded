package uk.co.umbaska.Replacers;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;

/**
 * Created by Zachary on 12/6/2015.
 */
public class EffBetterTeleport extends Effect{

    private Expression<Entity> ent;
    private Expression<Location> to;

    @Override
    protected void execute(Event event) {



    }

    @Override
    public String toString(Event event, boolean b) {
        return "Umbaska Better Teleport (to fix vehicles)";
    }

    @Override
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        this.ent = (Expression<Entity>) expressions[0];
        this.to = (Expression<Location>) expressions[1];
        return false;
    }
}
